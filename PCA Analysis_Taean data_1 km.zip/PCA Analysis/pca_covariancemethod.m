clc;
clear all;


load('Taeandata.mat')
load('TaeandataPCA_Labels.mat')
%load('Fruitdata.mat')
%load('Fruitlabels.mat') % load feature names
%figure()
%boxplot(Taeandata,'Orientation','horizontal','Labels',TaeandataPCA_Labels) 
%boxplot(Fruitdata,'Orientation','horizontal','Labels',Fruitlabels) 

%compute principal components

w = 1./var(Taeandata);
[wcoeff,score,latent,tsquared,explained] = pca(Taeandata,'VariableWeights',w);
%w = 1./var(Fruitdata);
%[wcoeff,score,latent,tsquared,explained] = pca(Fruitdata,'VariableWeights',w);

%[wcoeff,score,latent,tsquared,explained] = pc
a(data,'VariableWeights','variance');

%Create scree plot [equivalent to percentage of data coverage with these PCA]
figure()
pareto(explained)
xlabel('Principal Component')
ylabel('Variance Explained (%)') 

%Transform Coefficient
coefforth = diag(sqrt(w))*wcoeff;

V1 = var(coefforth);
V2 = var(wcoeff);

%edited
%load('coefforth_edited.mat')
%load('coefforthfruit.mat')
%figure()
%biplot(coefforth_edited(:,1:2),'Varlabels',PCAdata_labels);
%biplot(coefforthfruit(:,1:2),'Varlabels',Fruitlabels);
%axis([-0.8 0.8 -.8 .8]);

%visualize the result
grid on
figure()
biplot(coefforth(:,1:2),'Varlabels',TaeandataPCA_Labels);
axis([-0.8 0.8 -.8 .8]);

figure()
biplot(coefforth(:,3:4),'Varlabels',TaeandataPCA_Labels);
axis([-0.8 0.8 -.8 .8]);

figure()
biplot(coefforth(:,5:6),'Varlabels',TaeandataPCA_Labels);
axis([-0.8 0.8 -.8 .8]);

figure()
biplot(coefforth(:,7:8),'Varlabels',TaeandataPCA_Labels);
axis([-0.8 0.8 -.8 .8]);

figure()
biplot(coefforth(:,9:10),'Varlabels',TaeandataPCA_Labels);
axis([-0.8 0.8 -.8 .8]);



%X = data;

%z=score*wcoeff(:,1:11); % from expalined, 9 parameters cover more than 90% variances, more variances more information

%recovered_X = z*(wcoeff(:,1:9)')
%Z1 = X*coefforth_edited;


