clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%% Axis Setup %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% x, y, z = Combined MED, SNR, Coherence BW data,  mu= Mean, sigma = Standard Deviation %%%%%%%%%
%% Input whole dataset

load('QPSKCB_SNR_MED_half');
x = QPSKCB_SNR_MED_half;


minimum_x = min(x(:,1));
maximum_x = max(x(:,1));
size_QPSKCB_half = length(x(:,1)); % same size as size_MED16QAM
pd_x = fitdist(x(:,1),'Normal')
mu_x = mean(x(:,1));
sigma_x = std(x(:,1));
v_x = var(x(:,1));


%lowerbound_x = minimum_x;
%upperbound_x = 50;
lowerbound_x =  mu_x-1.2*sigma_x;
upperbound_x = mu_x+1.2*sigma_x;


minimum1_x = min(x(:,2));
maximum1_x = max(x(:,2));
size_QPSKSNR_half = length(x(:,2));
pd1_x = fitdist(x(:,2),'Normal')
mu1_x = mean(x(:,2));
sigma1_x = std(x(:,2));
v1_x = var(x(:,2));

%lowerbound1_x = minimum1_x;
%upperbound1_x = 7.5;

lowerbound1_x = mu1_x-1.2*sigma1_x;
upperbound1_x = mu1_x+1.2*sigma1_x;
%upperbound1_x = maximum1_x;

minimum2_x = min(x(:,3));
maximum2_x = max(x(:,3));
size_QPSKMED_half = length(x(:,3));
pd2_x = fitdist(x(:,3),'Normal')
mu2_x = mean(x(:,3));
sigma2_x = std(x(:,3));
v2_x = var(x(:,3));

%lowerbound2_x = 18;
%lowerbound2_x = minimum2_x;
%upperbound2_x = 24;
lowerbound2_x = mu2_x-1.2*sigma2_x;
upperbound2_x = mu2_x+1.2*sigma2_x;
%upperbound2_x = maximum2_x;

%[example c= [100 0.1;103 0.05; 302  0.35;  150 0.02]
%mask1 = c>100 & c<200
%x1 = c(mask1(:,1),:)
%mask2 = x1> 0.02
%x2 = x1(mask2(:,2),:)]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Apply SNR, MED, RMS Delay Threshold value/ truncated value for QPSK
%Finally we plot SNR vs MED vs RMS Delay plot
%we first truncate SNR data, than MED data, RMS Delay data so file size will be large if we
%do it inversely

index_x = x>lowerbound_x & x<upperbound_x
x1 = x(index_x(:,1),:);
size_x1 = length(x1);
minimum_x1 = min(x1);
maximum_x1 = max(x1);

index_x1 = x1>lowerbound1_x & x1<upperbound1_x
x2 = x1(index_x1(:,2),:)
size_x2 = length(x2);
minimum_x2 = min(x2);
maximum_x2 = max(x2);

index_x2 = x2>lowerbound2_x & x2<upperbound2_x
x3 = x2(index_x2(:,3),:)
size_x3 = length(x3);
minimum_x3 = min(x3);
maximum_x3 = max(x3);

%x3 = sortrows(x3,3)

percentage_of_data_coverage_16QAM_half = (size_x3/size_QPSKMED_half)*100 

%%%%%%%%%%%%%%% QPSK_onethird %%%%%%%%%%%%%%%%

load('QPSKCB_SNR_MED_onethird');
y = QPSKCB_SNR_MED_onethird;


minimum_y = min(y(:,1));
maximum_y = max(y(:,1));
size_QPSKCB_onethird = length(y(:,1)); % same size as size_16QAMMED
pd_y = fitdist(y(:,1),'Normal')
mu_y = mean(y(:,1));
sigma_y = std(y(:,1));
v_y = var(y(:,1));


%lowerbound_y = 50;
%upperbound_y = 32;

lowerbound_y = mu_y-1.2*sigma_y;
upperbound_y = mu_y+1.2*sigma_y;
%upperbound_y = maximum_y;

minimum1_y = min(y(:,2));
maximum1_y = max(y(:,2));
size_QPSKSNR_onethird = length(y(:,2));
pd1_y = fitdist(y(:,2),'Normal')
mu1_y = mean(y(:,2));
sigma1_y = std(y(:,2));
v1_y = var(y(:,2));


%lowerbound1_y = 7.5;
%lowerbound1_y = minimum1_y;
upperbound1_y = mu1_y+1.2*sigma1_y;

%upperbound1_y = maximum1_y;
lowerbound1_y = mu1_y-1.2*sigma1_y;
%upperbound1_y = 6.43;


minimum2_y = min(y(:,3));
maximum2_y = max(y(:,3));
size_QPSKMED_onethird = length(y(:,3));
pd2_y = fitdist(y(:,3),'Normal')
mu2_y = mean(y(:,3));
sigma2_y = std(y(:,3));
v2_y = var(y(:,3));


%lowerbound2_y = 24;
%upperbound2_y = maximum2_y;

%lowerbound2_y = minimum2_y;
upperbound2_y = mu2_y+1.2*sigma2_y;

lowerbound2_y = mu2_y-1.2*sigma2_y;
%upperbound2_y = 18;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Apply CB, SNR, MED Threshold value/ truncated value for QPSK
%Finally we plot CB, SNR, MED plot
%we first truncate CB data, then SNR data, then MED data then so file size will be large if we
%do it inversely

%index1 = x1<lowerbound1 | x1>upperbound1; 
index_y = y>lowerbound_y & y<upperbound_y
y1 = y(index_y(:,1),:);
size_y1 = length(y1);
minimum_y1 = min(y1);
maximum_y1 = max(y1);

%index = x<lowerbound | x>upperbound;
index_y1 = y1>lowerbound1_y & y1<upperbound1_y
y2 = y1(index_y1(:,2),:)
size_y2 = length(y2);
minimum_y2 = min(y2);
maximum_y2 = max(y2);

index_y2 = y2>lowerbound2_y & y2<upperbound2_y
y3 = y2(index_y2(:,3),:)
size_y3 = length(y3);
minimum_y3 = min(y3);
maximum_y3 = max(y3);

%y3 = sortrows(y3,3)

percentage_of_data_coverage_16QAM_onethird = (size_y3/size_QPSKMED_onethird)*100 

%%%%%%%%%%%%%%%% plot the graphs %%%%%%%%%%%%%%%%%%%

RGB = [255 153 153; 204 204 255];

pointsize = 5;

grid on;

scatter3(x(:,1), x(:,2), x(:,3), 'g', 'filled');
hold on
scatter3(y(:,1), y(:,2), y(:,3), 'c', 'filled');
hold on

scatter3(x3(:,1), x3(:,2), x3(:,3), 'b', 'filled');
hold on
scatter3(y3(:,1), y3(:,2), y3(:,3), 'r', 'filled');
hold on

legend ('All Data Coding Rate: 1/2', 'All Data Coding Rate: 1/3', 'Truncated Coding Rate: 1/2', 'Truncated Coding Rate: 1/3');
xlabel('Coherence BW');
ylabel('SNR'); 
zlabel('MED [-15 dB]');
%zlabel('RMS Delay'); 
%title('Scatter Plot of Link Adaptation of QPSK using Threshold Values');

A = [size_x3  size_y3];
B = [size_QPSKMED_half  size_QPSKMED_onethird];


overall_classification_accuracy = (sum(A)/sum(B))*100

