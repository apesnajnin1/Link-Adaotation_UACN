clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% rms_delayspread = RMS data, mu= Mean, sigma = Standard Deviation%%%%%%%%%

rms=load('QPSKRMS15dB_half');
rms= cell2mat(struct2cell(rms));
minimum = min(rms);
maximum = max(rms);
size_64QAM_half = length(rms);
pd = fitdist(rms,'Normal')
%pd = fitdist(rms,'Rayleigh')
mu = mean(pd);
sigma = std(pd);
v = var(pd);


%t = truncate(pd,mu-0.5*sigma,mu+0.5*sigma)
%t = truncate(pd,mu-sigma,mu+sigma)
t = truncate(pd,minimum,6.26)

lowerbound = mu-sigma;
upperbound = mu+sigma;

index = rms<lowerbound | rms>upperbound; 
rms(index)=[];
size = length(rms);

percentage = (size/size_64QAM_half)*100;

rms1=load('QPSKRMS15dB_onethird');
rms1= cell2mat(struct2cell(rms1));
minimum1 = min(rms1);
maximum1 = max(rms1);
size_64QAM_onethird = length(rms1);
pd1 = fitdist(rms1,'Normal')
%pd1 = fitdist(rms1,'Rayleigh')
mu1 = mean(pd1);
sigma1 = std(pd1);
v1 = var(pd1);

%t1 = truncate(pd1,mu1-0.5*sigma1,mu1+0.5*sigma1)
%t1 = truncate(pd1,mu1-sigma1,mu1+sigma1)
t1 = truncate(pd1,6.26,maximum1)

lowerbound1 = mu1-sigma1;
upperbound1 = mu1+sigma1;

index1 = rms1<lowerbound1 | rms1>upperbound1; 
rms1(index1)=[];
size1 = length(rms1)

percentage1 = (size1/size_64QAM_onethird)*100

x = 0:0.1:18;

grid on;

%plot(x,pdf(pd0,x));
%hold on

plot(x,pdf(pd,x), 'color', 'r');
hold on
plot(x,pdf(pd1,x), 'color', 'b');
hold on


legend('Coding Rate: 1/2','Coding Rate: 1/3')
xlabel('RMS Delay Spread [Threshold: -15 dB]')
ylabel('pdf of Gaussian Distribution')

title('Gaussian Distribution Curve of 64QAM RMS Delay Spread with coding rate');
hold off

figure;

plot(x,pdf(t,x), 'color', 'r');
hold on
plot(x,pdf(t1,x), 'color', 'b');
hold on

legend('Truncated Coding Rate: 1/2','Truncated Coding Rate: 1/3')
xlabel('RMS Delay Spread [Threshold: -15 dB]')
ylabel('pdf of Gaussian Distribution')
%title('Gaussian Distribution Curve of 64QAM RMS Delay Spread [mu-sigma, mu+sigma]');
hold off
