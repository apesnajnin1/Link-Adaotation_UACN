clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% snr = SNR data, mu= Mean, sigma = Standard Deviation %%%%%%%%%

snr=load('x64QAMSNR_half');
snr= cell2mat(struct2cell(snr));
minimum = min(snr);
maximum = max(snr);
size_16QAM_half = length(snr);


lowerbound = 5;
upperbound = maximum;

index = snr<lowerbound | snr>upperbound; 
snr(index)=[];
size = length(snr);

data_percentage = (size/size_16QAM_half)*100;

snr1=load('x64QAMSNR_onethird');
snr1= cell2mat(struct2cell(snr1));
minimum1 = min(snr1);
maximum1 = max(snr1);
size_16QAM_onethird = length(snr1);


lowerbound1 = minimum1;
upperbound1 = 5;

index1 = snr1<lowerbound1 | snr1>upperbound1; 
snr1(index1)=[];
size1 = length(snr1);

data_percentage1 = (size1/size_16QAM_onethird)*100;

A = [size              size1];
B = [size_16QAM_half    size_16QAM_onethird];


classification_accuracy = (sum(A)/sum(B))*100