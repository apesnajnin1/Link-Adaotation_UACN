clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%p= SNR data, mu= Mean, sigma = Standard Deviation%%%%%%%%%
%% Input whole dataset

SNR = load('QPSKSNR_half');
SNR = cell2mat(struct2cell(SNR));
minimum = min(SNR);
maximum = max(SNR);
size_16QAM_half = length(SNR);
pd = fitdist(SNR,'Normal')
%pd = fitdist(SNR,'Rayleigh')
mu = mean(SNR);
sigma = std(SNR);
v = var(SNR);

%t = truncate(pd, mu-sigma, mu+sigma)
%t = truncate(pd, mu-0.5*sigma, mu+0.5*sigma)
t = truncate(pd, minimum, 7.5)

lowerbound = mu-sigma;
upperbound = mu+sigma;
index = SNR<lowerbound | SNR>upperbound; 
SNR(index)=[];
size = length(SNR)

percentage = (size/size_16QAM_half)*100


SNR1 = load('QPSKSNR_onethird');
SNR1 = cell2mat(struct2cell(SNR1));
minimum1 = min(SNR1);
maximum1 = max(SNR1);
size_16QAM_onethird = length(SNR1);
pd1 = fitdist(SNR1,'Normal')
%pd1 = fitdist(SNR1,'Rayleigh')
mu1 = mean(SNR1);
sigma1 = std(SNR1);
v1 = var(SNR1);


%t1 = truncate(pd1, mu1-sigma1, mu1+sigma1)
%t1 = truncate(pd1, mu1-0.5*sigma1, mu1+0.5*sigma1)
t1 = truncate(pd1, 7.5, maximum1)

lowerbound1 = mu1-sigma1;
upperbound1 = mu1+sigma1;
index1 = SNR1<lowerbound1 | SNR1>upperbound1; 
SNR1(index1)=[];
size1 = length(SNR1)

percentage1 = (size1/size_16QAM_onethird)*100


x = 0:0.1:20;

grid on

plot(x,pdf(pd,x), 'Color', 'r')
hold on
plot(x,pdf(pd1,x), 'Color', 'b')
hold on

legend('Coding Rate: 1/2','Coding Rate: 1/3')
xlabel('SNR')
ylabel('pdf of Gaussian Distribution')
title('Gaussian Distribution Curve of 64QAM SNR with coding rate');
hold off

figure();
plot(x,pdf(t,x), 'Color', 'r')
hold on
plot(x,pdf(t1,x), 'Color', 'b')
hold on


legend('Truncated Coding Rate: 1/2','Truncated Coding Rate: 1/3')
xlabel('SNR')
ylabel('pdf of Gaussian Distribution')
%title('Gaussian Distribution Curve of 64QAM SNR with coding rate [mu-sigma, mu+sigma]');
hold off
