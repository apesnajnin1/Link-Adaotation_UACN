clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% Coherence BW = Mean Estimated Delay data, mu= Mean, sigma = Standard Deviation%%%%%%%%%



CB=load('QPSKCB15dBcorr5_half');
CB= cell2mat(struct2cell(CB));
minimum = min(CB);
maximum = max(CB);
size_64QAM_half = length(CB);
pd = fitdist(CB,'Normal')
%pd = fitdist(CB,'Rayleigh')
mu = mean(pd);
sigma = std(pd);
v = var(pd);


%t = truncate(pd,mu-0.5*sigma,mu+0.5*sigma)
%t = truncate(pd,mu-sigma,mu+sigma)
t = truncate(pd,minimum,180)

lowerbound = mu-sigma;
upperbound = mu+sigma;

index = CB<lowerbound | CB>upperbound; 
CB(index)=[];
size = length(CB);

percentage = (size/size_64QAM_half)*100;

CB1=load('QPSKCB15dBcorr5_onethird');
CB1= cell2mat(struct2cell(CB1));
minimum1 = min(CB1);
maximum1 = max(CB1);
size_64QAM_onethird = length(CB1);
pd1 = fitdist(CB1,'Normal')
%pd1 = fitdist(CB1,'Rayleigh')
mu1 = mean(pd1);
sigma1 = std(pd1);
v1 = var(pd1);

%t1 = truncate(pd1,mu1-0.5*sigma1,mu1+0.5*sigma1)
%t1 = truncate(pd1,mu1-sigma1,mu1+sigma1)
t1 = truncate(pd1,180,maximum1)

lowerbound1 = mu1-sigma1;
upperbound1 = mu1+sigma1;

index1 = CB1<lowerbound1 | CB1>upperbound1; 
CB1(index1)=[];
size1 = length(CB1)

percentage1 = (size1/size_64QAM_onethird)*100

x = 0:1:1550;

grid on;

plot(x,pdf(pd,x), 'color', 'r');
hold on
plot(x,pdf(pd1,x), 'color', 'b');
hold on



%legend('Coding rate: 1/2','Coding rate: 1/3')
xlabel('Coherence BW [Threshold: -15 dB][corr 5]')
ylabel('pdf of Gaussian Distribution')
%title('Gaussian Distribution Curve of 64QAM Coherence BW');
hold off

figure;

plot(x,pdf(t,x), 'color', 'r');
hold on
plot(x,pdf(t1,x), 'color', 'b');


legend('Truncated Coding rate: 1/2','Truncated Coding rate: 1/3')
xlabel('Coherence BW [Threshold: -15 dB][corr 5]')
ylabel('pdf of Gaussian Distribution')
%title('Gaussian Distribution Curve of Coherence BW [mu-0.5*sigma, mu+0.5*sigma]');
%title('Gaussian Distribution Curve of 64QAM Coherence BW [mu-sigma, mu+sigma]');
hold off
