clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% MED = Mean Estimated Delay data, mu= Mean, sigma = Standard Deviation%%%%%%%%%



med=load('QPSKMED15dB_half');
med= cell2mat(struct2cell(med));
minimum = min(med);
maximum = max(med);
size_16QAM_half = length(med);
pd = fitdist(med,'Normal')
%pd = fitdist(med,'Rayleigh')
mu = mean(pd);
sigma = std(pd);
v = var(pd);


%t = truncate(pd,mu-0.5*sigma,mu+0.5*sigma)
%t = truncate(pd,mu-sigma,mu+sigma)
t = truncate(pd,24,maximum)

lowerbound = mu-sigma;
upperbound = mu+sigma;

index = med<lowerbound | med>upperbound; 
med(index)=[];
size = length(med);

percentage = (size/size_16QAM_half)*100;

med1=load('QPSKMED15dB_onethird');
med1= cell2mat(struct2cell(med1));
minimum1 = min(med1);
maximum1 = max(med1);
size_16QAM_onethird = length(med1);
pd1 = fitdist(med1,'Normal')
%pd1 = fitdist(med1,'Rayleigh')
mu1 = mean(pd1);
sigma1 = std(pd1);
v1 = var(pd1);

%t1 = truncate(pd1,mu1-sigma1,mu1+sigma1)
%t1 = truncate(pd1,mu1-sigma1,mu1+sigma1)
t1 = truncate(pd1,minimum1, 24)

lowerbound1 = mu1-sigma1;
upperbound1 = mu1+sigma1;

index1 = med1<lowerbound1 | med1>upperbound1; 
med1(index1)=[];
size1 = length(med1)

percentage1 = (size1/size_16QAM_onethird)*100

x = 0:0.1:50;

grid on;

plot(x,pdf(pd,x), 'color', 'r');
hold on
plot(x,pdf(pd1,x), 'color', 'b');
hold on



legend('Coding rate: 1/2','Coding rate: 1/3')
xlabel('MED [Threshold: -15 dB]')
ylabel('pdf of Gaussian Distribution')
%title('Normal Distribution Curve of BPSK, QPSK, 16QAM and 64QAM MED of Taean Data');
title('Gaussian Distribution Curve of 64QAM MED');
hold off

figure;

plot(x,pdf(t,x), 'color', 'r');
hold on
plot(x,pdf(t1,x), 'color', 'b');

%legend('Truncated BPSK MED','Truncated QPSK MED','Truncated 16QAM MED', 'Truncated 64QAM MED')

legend('Truncated Coding rate: 1/2','Truncated Coding rate: 1/3')
xlabel('MED [Threshold: -15 dB]')
ylabel('pdf of Gaussian Distribution')
%title('Gaussian Distribution Curve of 64QAM MED [mu-sigma, mu+sigma]');
hold off
