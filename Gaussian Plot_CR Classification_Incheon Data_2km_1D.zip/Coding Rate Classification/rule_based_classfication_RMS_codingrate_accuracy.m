clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% rms_delayspread = RMS data, mu= Mean, sigma = Standard Deviation%%%%%%%%%

%%%%%% coding rate %%%%%%%%

rms=load('x64QAMRMS15dB_half');
rms= cell2mat(struct2cell(rms));
minimum = min(rms);
maximum = max(rms);
size_64QAM_half = length(rms);

lowerbound = minimum;
upperbound = 7.8;
%lowerbound = 3.5153;
%upperbound = 11.9567;

index = rms<lowerbound | rms>upperbound; 
rms(index)=[];
size = length(rms);

data_percentage = (size/size_64QAM_half)*100;

rms1=load('x64QAMRMS15dB_onethird');
rms1= cell2mat(struct2cell(rms1));
minimum1 = min(rms1);
maximum1 = max(rms1);
size_64QAM_onethird = length(rms1);

lowerbound1 = 7.8;
upperbound1 = maximum1;

index1 = rms1<lowerbound1 | rms1>upperbound1; 
rms1(index1)=[];
size1 = length(rms1);

data_percentage1 = (size1/size_64QAM_onethird)*100;


A = [size            size1];
B = [size_64QAM_half  size_64QAM_onethird];


classification_accuracy = (sum(A)/sum(B))*100