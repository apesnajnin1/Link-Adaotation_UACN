%Accuracy of code rate classification

clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% Coherence BW = Coherence Bandwidth data, mu= Mean, sigma = Standard Deviation %%%%%%%%%

CB=load('x64QAMCB15dBcorr5_half');
CB= cell2mat(struct2cell(CB));
minimum = min(CB);
maximum = max(CB);
size_16QAM_half = length(CB);


lowerbound = minimum;
upperbound = 41.33;

index = CB<lowerbound | CB>upperbound; 
CB(index)=[];
size = length(CB);

data_percentage = (size/size_16QAM_half)*100;

CB1=load('x16QAMCB15dBcorr5_onethird');
CB1= cell2mat(struct2cell(CB1));
minimum1 = min(CB1);
maximum1 = max(CB1);
size_16QAM_onethird = length(CB1);


lowerbound1 = 41.33;
upperbound1 = maximum1;

index1 = CB1<lowerbound1 | CB1>upperbound1; 
CB1(index1)=[];
size1 = length(CB1);

data_percentage1 = (size1/size_16QAM_onethird)*100;


A = [size               size1];
B = [size_16QAM_half    size_16QAM_onethird];


classification_accuracy = (sum(A)/sum(B))*100