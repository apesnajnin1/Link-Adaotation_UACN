clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% MED = Mean Estimated Delay data, mu= Mean, sigma = Standard Deviation %%%%%%%%%

med=load('x64QAMMED15dB_half');
med= cell2mat(struct2cell(med));
minimum = min(med);
maximum = max(med);
size_x16QAM_half = length(med);


lowerbound = minimum;
upperbound = 32.8862;

index = med<lowerbound | med>upperbound; 
med(index)=[];
size = length(med);

data_percentage = (size/size_x16QAM_half)*100;

med1=load('x64QAMMED15dB_onethird');
med1= cell2mat(struct2cell(med1));
minimum1 = min(med1);
maximum1 = max(med1);
size_x16QAM_onethird = length(med1);

lowerbound1 = 32.8862;
upperbound1 = maximum1;

index1 = med1<lowerbound1 | med1>upperbound1; 
med1(index1)=[];
size1 = length(med1);

data_percentage1 = (size1/size_x16QAM_onethird)*100;


A = [size                size1];
B = [size_x16QAM_half    size_x16QAM_onethird];


classification_accuracy = (sum(A)/sum(B))*100