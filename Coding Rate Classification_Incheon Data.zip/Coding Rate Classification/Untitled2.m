%x = load('QPSKTurboratedata_04');
%x = table2struct(x);
%x = cell2mat(table2cell(x));


%index1_x = x>lowerbound1_x & x<upperbound1_x
%x1 = x(index1_x(:,2),:);
%size1_x1 = length(x1);

load QPSKTurboCodingRate
categories(QPSKTurboCodingRate)

load QPSKCB15dBcorr5
load QPSKRMS15dB
load QPSKMED15dB
load QPSKSNR

p = QPSKTurboCodingRate;
z = QPSKCB15dBcorr5;
y = QPSKRMS15dB;
q = QPSKMED15dB;
x = QPSKSNR; 



scatter3(p,q,z,'MarkerEdgeColor','r','MarkerFaceColor','c') %[0 .75 .75])


zlabel('CB[-15 dB][corr5]')
%ylabel('RMS [-15 dB]')
xlabel('Coding Rate')

ylabel('MED [-15 dB]')
%ylabel('SNR')

title('3D plot of Turbo Coded QPSK data')

figure();
%scatter(p,q,'MarkerEdgeColor','r','MarkerFaceColor','g')
scatter(z,x,'r','filled')
xlabel('Coding Rate')
ylabel('CB[-15 dB][corr5]')

%legend ('SNR','MED')
title('2D plot of Turbo Coded QPSK data')

%hold on

figure();
scatter(z,y,'c','filled')

xlabel('Coding Rate')
ylabel('RMS [-15 dB]')

%legend ('SNR','MED')
title('2D plot of Turbo Coded QPSK data')

%scatter(x2(:,1), x2(:,2), 'g', 'filled');

%scatter3(x,y,z,'MarkerEdgeColor','r','MarkerFaceColor','c') %[0 .75 .75]
%figure();

%legend ('MED','SNR','Coding Rate')




