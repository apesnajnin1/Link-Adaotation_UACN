%2D interpolation

clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%X=BER, Y=Data Rate, Z= RMS%%%%%%%%%
x=load('BER');
y=load('DR');
z = load('RMS');



x= cell2mat(struct2cell(x));
y= cell2mat(struct2cell(y));
z= cell2mat(struct2cell(z));

F = scatteredInterpolant(x,y,z);

xlin = linspace(min(x),max(x),100);
ylin = linspace(min(y),max(y),100);
[X,Y] = meshgrid(xlin,ylin);

F.Method = 'linear';
V = F(X,Y);

figure
surf(X,Y,V) %interpolated
axis tight; hold on 


%mesh(X,Y,V) %interpolated
%axis tight; hold on 




view(3)
grid on
hold on



plot3(x,y,z,'O','MarkerSize',6) %nonuniform

xlabel('BER')
%zlabel('Data Rate(bps)')
%ylabel('RMS(ms)')
ylabel('Data Rate(bps)')
zlabel('Interpolated values')
title('2D linear interpolated data')

