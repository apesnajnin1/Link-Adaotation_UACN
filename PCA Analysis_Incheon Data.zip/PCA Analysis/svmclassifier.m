%load fisheriris 
%inds = ~ strcmp (species, 'setosa' );
%X = meas (inds, 3: 4);
%y = species (inds);

%SVMModel = fitcsvm (X, y)

%SVMModel = fitcsvm(X,Y,'Standardize',true,'KernelFunction','RBF',...
%    'KernelScale','auto');
%classOrder = SVMModel.ClassNames

%sv = SVMModel.SupportVectors;
%figure
%gscatter (X (:, 1), X (:, 2), y)
%hold on 
%plot (sv (:, 1), sv (:, 2), 'ko' , 'MarkerSize' , 10)
%legend ( 'versicolor' , 'virginica' , 'Support Vector' )
%hold off

load incheondataset 
%inds = ~ strcmp (species, 'setosa' );
%X = meas (:, 3: 4);
X = meas (:, 14:10);

%y = species (inds);

%SVMModel = fitcsvm (X, y)
%classOrder = SVMModel.ClassNames

%sv = SVMModel.SupportVectors;
%figure
%gscatter (X (:, 1), X (:, 2), y)
%hold on 
%plot (sv (:, 1), sv (:, 2), 'ko' , 'MarkerSize' , 10)
%legend ( 'versicolor' , 'virginica' , 'Support Vector' )
%hold off
