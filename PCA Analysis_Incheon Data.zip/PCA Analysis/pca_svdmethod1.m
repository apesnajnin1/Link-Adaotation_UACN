% This function calculates the covariance matrix (Sigma) and then performs 
% svd on it to get the eigen vectors and eigen values

clear all;
clc;
topeig = 12;


load('data.mat')
load('PCAdata_labels.mat') % load feature names
X = data;

mu = mean(X);
stddev = std(X);
XNorm = bsxfun(@minus,X,mu); % subtract mean of each feature from original value
XNorm = bsxfun(@rdivide,XNorm,stddev); % divide by standard deviation

%[X mu stddev]  = normalizeFeatures(X);

X1 = XNorm;

[m n] = size(X1); % m - no of egs; n - no of features
Sigma = (1/m)*(X1')*(X1); % Covariance matrix
[U S V] = svd(Sigma); % Perform Singular Value Decomposition

%displayData(X, U(:, 1:topeig)');

[U,S] = performPCA(X);
displayData(U(:, 1:topeig)');


%load('coefforthfruit.mat')
%figure()
%biplot(coefforth_edited(:,1:2),'Varlabels',PCAdata_labels);
%biplot(coefforthfruit(:,1:2),'Varlabels',Fruitlabels);
%axis([-0.8 0.8 -.8 .8]);