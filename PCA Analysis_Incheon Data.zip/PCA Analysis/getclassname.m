function classOrder = getclassname(CMdl, X, Y)

BER1 = 0.1701;
DR1 = 1083;
RMS1 = 7.5;
BER2 = 0.22034;
DR2 = 1936;
RMS2


p = X(:, 1);
q = X(:, 2);

for i = 1: 9142
    for j = 1: 9142
        if p(i) <ber1 && q(j) <DR1
            classOrder = {'QPSK'}
        elseif ber1 < p(i) < ber2 && DR1 < q(j) <DR2
            classOrder = {'16QAM'}
        elseif p(i) < ber2 && q(j) <DR2
            classOrder = {'64QAM'}
        else fprintf ('error message: unpredictable label/ erroneous received message \n')
        end
    end
end
return;