% Power Method Algorithm
function [vec,value]=power_method(x,A,tol)
%
%Power method for computing eigenvalues
%
dd=1;

n=10; % maximum number iteration
while dd> tol
y=A.*x
dd=abs(norm(x)-n)

n=norm(x)
x=y/n
%pause
end
vec=x;
value=n;