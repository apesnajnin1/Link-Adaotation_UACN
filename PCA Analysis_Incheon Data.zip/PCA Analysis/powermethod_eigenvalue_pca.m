%Power Method Algorithm
%main program
clc;
clear all;

load PCAdata02
A = PCAdata02; 

% Find out the size of data
p = length(A);

x = zeros(1,p);
y = zeros(1,p);

tol = 10^-3; 

x = ones(1,02);


%A =[1 2 0; -2 1 2; 1 3 1];
%x = [1 1 1];
%x = [1 0 1];

[vec,value]=power_method(x,A,tol)