
clear;
clc;
tic;
load data   % output from pca_covariancemethod
load modulations
X = data; 
Y = categorical(modulations);

[coeff,score,latent,tsquared,explained,mu] = pca(data);