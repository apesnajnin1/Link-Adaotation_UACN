%Incheon Dataset, considering coding rate
%F = scatteredInterpolant(x,y,z,v) creates a 3-D interpolant of the form v = F(x,y,z).
%F = scatteredInterpolant(x,y,v) creates an interpolant that fits a surface of the form v = F(x,y). 
%Vectors x and y specify the (x,y) coordinates of the sample points. v is a vector that contains 
%the sample values associated with the points (x,y).
%for 1D, griddedinterpolation, but here grid vector should be increased
%monotonically
clear all;
clc;
%%%%%%%%%%%%%%%%%%% Axis Setup %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% X= QPSKRMS, Y= QPSKMED , Z= v = QPSKCohBW or QPSKSNR %%%%%%%%%

%%%%%%%%%%%% code rate = 1/2 %%%%%%%%%%%%%%%%
load x64QAMCB15dBcorr5_half
load x64QAMRMS15dB_half
load x64QAMMED15dB_half
load x64QAMSNR_half

z = x64QAMCB15dBcorr5_half;
y = x64QAMRMS15dB_half;
v = x64QAMMED15dB_half;
x = x64QAMSNR_half; 

F = scatteredInterpolant(x,y,v);  % v may be a function of x and y or may be random data
                                    %F = griidedInterpolant(x,v);  % 1D
x_range = linspace(min(x),max(x),100);
y_range = linspace(min(y),max(y),100);


[xq,yq] = meshgrid(x_range,y_range);
                                 %[xq] = meshgrid(x_range);
F.Method = 'natural';     % interpolation method: 'nearest', 'linear', or 'natural'
vq = F(xq,yq);
                                 %vq = F(xq);
                                 
%%%%% coderate = 1/3 %%%%%%%%%

load x64QAMCB15dBcorr5_onethird
load x64QAMRMS15dB_onethird
load x64QAMMED15dB_onethird
load x64QAMSNR_onethird

%x = QPSKTurboCodingRate;
z1 = x64QAMCB15dBcorr5_onethird;
y1 = x64QAMRMS15dB_onethird;
v1 = x64QAMMED15dB_onethird;
x1 = x64QAMSNR_onethird; 


F1 = scatteredInterpolant(x1,y1,v1);  % v may be a function of x and y or may be random data

                                  %F = griidedInterpolant(x,v);  % 1D
x1_range = linspace(min(x1),max(x1),100);
y1_range = linspace(min(y1),max(y1),100);

[xq1,yq1] = meshgrid(x1_range,y1_range);
                                 %[xq] = meshgrid(x_range);

F1.Method = 'natural';     % interpolation method: 'nearest', 'linear', or 'natural'
vq1 = F(xq1,yq1);
                                 %vq = F(xq);


%%%%%%%%%%%%%%% plot 3D data %%%%%%%%%%%%%%%%%%%                               
grid on
view(3)
plot3(x,y,v,'O', 'Color', 'r','MarkerSize',10,'MarkerFaceColor','c') %nonuniform  , '#D9FFFF'

hold on

view(3)
plot3(x1,y1,v1,'O', 'Color', 'y','MarkerSize',10,'MarkerFaceColor','#D95319') %nonuniform  , '#D9FFFF'

hold on
s = mesh(xq,yq,vq); %interpolated
s.EdgeColor = '#A2142F';
s.FaceColor = '#4DBEEE';

hold on

s1 = mesh(xq1,yq1,vq1)  %interpolated             mesh(peaks)
                                                       %colormap(autumn(5))
s1.EdgeColor = '#4DBEEE';
s1.FaceColor = 'y';
                                
hold off

%xlabel('Coherence BW')
zlabel('MED [-15 dB]')
xlabel('SNR')
ylabel('RMS [-15 dB]')
legend('coderate: 1/2','coderate: 1/3')
%title('3D Natural Interpolated data of 64QAM')

