%Incheon Dataset, considering coding rate
%F = scatteredInterpolant(x,y,z,v) creates a 3-D interpolant of the form v = F(x,y,z).
%F = scatteredInterpolant(x,y,z,v) creates an interpolant that fits a surface of the form v = F(x,y,z). 
%Vectors x and y and z specify the (x,y,z) coordinates of the sample points. v is a vector that contains 
%the sample values associated with the points (x,y,z).
%for 1D, griddedinterpolation, but here grid vector should be increased
%monotonically
clear all;
clc;
%%%%%%%%%%%%%%%%%%% Axis Setup %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% X= QPSKRMS, Y= QPSKMED , Z= v = QPSKCohBW or QPSKSNR %%%%%%%%%


%%%%%%%%%%%% code rate = 1/2 %%%%%%%%%%%%%%%%
load x64QAMCB15dBcorr5_half
load x64QAMRMS15dB_half
load x64QAMMED15dB_half
load x64QAMSNR_half


v = x64QAMCB15dBcorr5_half;
%v = v/15;
%v = v/10;
y = x64QAMRMS15dB_half;
%y = y*10;
x = x64QAMMED15dB_half;
%x = x*10;
z = x64QAMSNR_half; 
%z = z*10;
z = (z+5)*10;

F = scatteredInterpolant(x,y,z,v);  % v may be a function of x and y or may be random data

                                  %F = griidedInterpolant(x,v);  % 1D
x_range = linspace(min(x),max(x),100);
y_range = linspace(min(y),max(y),100);
z_range = linspace(min(z),max(z),100);


[xq,yq,zq] = meshgrid(x_range,y_range,z_range);
                                 %[xq] = meshgrid(x_range);
F.Method = 'natural';     % interpolation method: 'nearest', 'linear', or 'natural'
vq = F(xq,yq,zq);
                                 %vq = F(xq);
                                 
%%%%% coderate = 1/3 %%%%%%%%%

load x64QAMCB15dBcorr5_onethird
load x64QAMRMS15dB_onethird
load x64QAMMED15dB_onethird
load x64QAMSNR_onethird


v1 = x64QAMCB15dBcorr5_onethird;
%v1 = v1/15;
%v1 = v1/10;
y1 = x64QAMRMS15dB_onethird;
%y1 = y1*10;
x1 = x64QAMMED15dB_onethird;
%x1 = x1*10;
z1 = x64QAMSNR_onethird; 
%v1 = v1*10;
z1 = (z1+5)*10;


F1 = scatteredInterpolant(x1,y1,z1,v1);  % v may be a function of x and y or may be random data

                                  %F = griidedInterpolant(x,v);  % 1D
x1_range = linspace(min(x1),max(x1),100);
y1_range = linspace(min(y1),max(y1),100);
z1_range = linspace(min(z1),max(z1),100);
[xq1,yq1,zq1] = meshgrid(x1_range,y1_range,z1_range);
                                 %[xq] = meshgrid(x_range);

F1.Method = 'linear';     % interpolation method: 'nearest', 'linear', or 'natural'
vq1 = F(xq1,yq1,zq1);
                                 %vq = F(xq);


%%%%%%%%%%%%%%% plot 3D data %%%%%%%%%%%%%%%%%%%                               
grid on
view(3)

scatter3(x,y,z,v,'MarkerEdgeColor','r','MarkerFaceColor', 'c') %nonuniform  , 'c', '#D9FFFF'  /[0 .75 .75]) 
hold on

view(3)

scatter3(x1,y1,z1,v1, 'MarkerEdgeColor','y','MarkerFaceColor','#D95319') %nonuniform  , '#D9FFFF'

                              
hold off



%zlabel('Coherence BW')
xlabel('MED [-15 dB]')
zlabel('SNR')
ylabel('RMS [-15 dB]')
legend('coderate: 1/2','coderate: 1/3')
%title('4D Natural Interpolated data of 64QAM')

