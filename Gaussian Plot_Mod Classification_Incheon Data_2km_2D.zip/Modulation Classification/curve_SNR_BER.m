clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%x= Combined DR and BER data, mu= Mean, sigma = Standard Deviation%%%%%%%%%
%% Input whole dataset

%load('QPSKSNR_BER_all');
%x = QPSKSNR_BER_all;

load('SNR_EVM_181121');
x = SNR_EVM_181121;


%%%%%%%%%%%%%%% 16QAM %%%%%%%%%%%%%%%%

%load('x16QAMSNR_BER_all');
%y = x16QAMSNR_BER_all;

load('SNR_EVM_181123_2');
y = SNR_EVM_181123_2;



%%%%%%%%%%%%%%% 64QAM %%%%%%%%%%%%%%%%

%load('x64QAMSNR_BER_all');
%z = x64QAMSNR_BER_all;



%%%%%%%%%%%%%%%% plot the graphs %%%%%%%%%%%%%%%%%%%

RGB = [255 153 153; 204 204 255];

pointsize = 5;
%scatter(x, y, pointsize, RGB, 'filled');

grid on;
%semilogy(x(:,1), x(:,2));
%hold on
%semilogy(y(:,1), y(:,2));
%hold on
%semilogy(z(:,1), z(:,2));
%legend ('QPSK', '16QAM', '64QAM');
%xlabel('SNR'); ylabel ('Coded BER');
%title('Semilogy plot of SNR vs BER');


semilogy(x(:,1), x(:,2));
axis([-24  24  10^-1  2.5*10^1]);
legend ('Namhaeang Data 181121');
xlabel('SNR'); ylabel ('EVM');
title('Semilogy plot of SNR vs EVM');

figure();
semilogy(y(:,1), y(:,2));
axis([-24  24  10^-1  2.5*10^1]);
legend ('Namhaeang Data 181123_2');
xlabel('SNR'); ylabel ('EVM');
title('Semilogy plot of SNR vs EVM');

%figure();
%scatter(x2(:,1), x2(:,2), 'g', 'filled');
%hold on
%scatter(y2(:,1), y2(:,2), 'r', 'filled');
%hold on
%scatter(z2(:,1), z2(:,2), 'b', 'filled');

%legend ('QPSK', '16QAM', '64QAM');
%xlabel('SNR'); ylabel ('Coded BER');
%title('Scatter Plot of Link Adaptation [mu-sigma, mu+sigma]');


%plot all data together

%load('SNR_BER_all');
%p = SNR_BER_all;

%figure();
%semilogy(p(:,1), p(:,2));
%legend ('All data');
%xlabel('SNR'); ylabel ('Coded BER');
%title('Semilogy plot of SNR vs BER');


