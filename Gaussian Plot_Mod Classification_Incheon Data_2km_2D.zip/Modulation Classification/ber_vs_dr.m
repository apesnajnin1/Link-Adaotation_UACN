clear all;
clc;

%% calculate the sigma range and percentage of data in 'bergauss.m'
%% Here, input the [-sigma,sigma]/ [mu, mu+sigma] ranged Dataset. Then plot the BER vs Data rate graph in 'ber_vs_dr.m'
%% Find out the thresholds of QPSK, 16QAM and 64QAM with less overlapped data by changing the sigma value
%% Finally classify the modulation with whole dataset and calculate the accuracy

DR = load('DRQPSK_mu_sigma');
DR = cell2mat(struct2cell(DR)); 

DR1 = load('DR16QAM_mu_sigma');
DR1 = cell2mat(struct2cell(DR1)); 

DR2 = load('DR64QAM_mu_sigma');
DR2 = cell2mat(struct2cell(DR2)); 


ber = load('CodedBERQPSK_mu_sigma');
ber = cell2mat(struct2cell(ber)); 


ber1 = load('CodedBER16QAM_mu_sigma');
ber1 = cell2mat(struct2cell(ber1));


ber2 = load('CodedBER64QAM_mu_sigma');
ber2 = cell2mat(struct2cell(ber2));

RGB = [255 153 153; 204 204 255];

pointsize = 5;
%scatter(x, y, pointsize, RGB, 'filled');


grid on;
scatter(ber, DR, 'g', 'filled');
hold on
scatter(ber1, DR1, 'r', 'filled');
hold on
scatter(ber2, DR2, 'b', 'filled');


%for finding thresholding, link adaptation

%scatter3(score(:,1),score(:,2),score(:,3))
%axis equal
%xlabel('1st Principal Component')
%ylabel('2nd Principal Component')
%zlabel('3rd Principal Component')


legend ('QPSK', '16QAM', '64QAM');
xlabel('ber'); ylabel ('data rate');
title('Scatter Plot of Link Adaptation [mu,mu+sigma]');