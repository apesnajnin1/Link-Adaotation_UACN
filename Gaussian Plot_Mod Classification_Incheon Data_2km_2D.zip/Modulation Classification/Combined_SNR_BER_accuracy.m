clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%x= Combined DR and BER data, mu= Mean, sigma = Standard Deviation%%%%%%%%%
%% Input whole dataset

load('QPSKSNR_BER_all');
x = QPSKSNR_BER_all;


minimum_x = min(x(:,1));
maximum_x = max(x(:,1));
size_SNRQPSK = length(x(:,1)); % same size as size_DRQPSK
pd_x = fitdist(x(:,1),'Normal')
mu_x = mean(x(:,1));
sigma_x = std(x(:,1));
v_x = var(x(:,1));

t_x = truncate(pd_x, mu_x-sigma_x, mu_x+sigma_x)

lowerbound_x = mu_x-sigma_x;
upperbound_x = mu_x+sigma_x;


minimum1_x = min(x(:,2));
maximum1_x = max(x(:,2));
size_BERQPSK = length(x(:,2));
pd1_x = fitdist(x(:,2),'Normal')
mu1_x = mean(x(:,2));
sigma1_x = std(x(:,2));
v1_x = var(x(:,2));

t1_x = truncate(pd1_x, mu1_x-sigma1_x, mu1_x+sigma1_x)

lowerbound1_x = mu1_x-sigma1_x;
upperbound1_x = mu1_x+sigma1_x;

%[example c= [100 0.1;103 0.05; 302  0.35;  150 0.02]
%mask1 = c>100 & c<200
%x1 = c(mask1(:,1),:)
%mask2 = x1> 0.02
%x2 = x1(mask2(:,2),:)]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Apply Data Rate and Coded BER Threshold value/ truncated value for QPSK
%Finally we plot BER vs DR plot
%we first truncate DR data, than BER data, so file size will be large if we
%do it inversely


%index = x<lowerbound | x>upperbound;

index_x = x>lowerbound_x & x<upperbound_x
x1 = x(index_x(:,1),:)
size1_x1 = length(x1);
minimum_x1 = min(x1);
maximum_x1 = max(x1);

%index1 = x1<lowerbound1 | x1>upperbound1; 
index1_x1 = x1>lowerbound1_x & x1<upperbound1_x
x2 = x(index1_x1(:,2),:);
size2_x2 = length(x2);
minimum_x2 = min(x2);
maximum_x2 = max(x2);



x2 = sortrows(x2,1)

percentage_of_data_coverage_QPSK = (size2_x2/size_SNRQPSK)*100 

%%%%%%%%%%%%%%% 16QAM %%%%%%%%%%%%%%%%

load('x16QAMSNR_BER_all');
y = x16QAMSNR_BER_all;


minimum_y = min(y(:,1));
maximum_y = max(y(:,1));
size_SNR16QAM = length(y(:,1)); % same size as size_DRQPSK
pd_y = fitdist(y(:,1),'Normal')
mu_y = mean(y(:,1));
sigma_y = std(y(:,1));
v_y = var(y(:,1));

t_y = truncate(pd_y, mu_y-sigma_y, mu_y+sigma_y)

lowerbound_y = mu_y-sigma_y;
upperbound_y = mu_y+sigma_y;


minimum1_y = min(y(:,2));
maximum1_y = max(y(:,2));
size_BER16QAM = length(y(:,2));
pd1_y = fitdist(y(:,2),'Normal')
mu1_y = mean(y(:,2));
sigma1_y = std(y(:,2));
v1_y = var(y(:,2));

t1_y = truncate(pd1_y, mu1_y-sigma1_y, mu1_y+sigma1_y)

lowerbound1_y = mu1_y-sigma1_y;
upperbound1_y = mu1_y+sigma1_y;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Apply Data Rate and Coded BER Threshold value/ truncated value for QPSK
%Finally we plot BER vs DR plot
%we first truncate DR data, than BER data, so file size will be large if we
%do it inversely

%index = x<lowerbound | x>upperbound;

index_y = y>lowerbound_y & y<upperbound_y
y1 = y(index_y(:,1),:)
size1_y1 = length(y1);
minimum_y1 = min(y1);
maximum_y1 = max(y1);

%index1 = x1<lowerbound1 | x1>upperbound1; 
index1_y1 = y1>lowerbound1_y & y1<upperbound1_y
y2 = y1(index1_y1(:,2),:);
size2_y2 = length(y2);
minimum_y2 = min(y2);
maximum_y2 = max(y2);


y2 = sortrows(y2,1)

percentage_of_data_coverage_16QAM = (size2_y2/size_SNR16QAM)*100 

%%%%%%%%%%%%%%% 64QAM %%%%%%%%%%%%%%%%

load('x64QAMSNR_BER_all');
z = x64QAMSNR_BER_all;


minimum_z = min(z(:,1));
maximum_z = max(z(:,1));
size_SNR64QAM = length(z(:,1)); % same size as size_DRQPSK
pd_z = fitdist(z(:,1),'Normal')
mu_z = mean(z(:,1));
sigma_z = std(z(:,1));
v_z = var(z(:,1));

t_z = truncate(pd_z, mu_z-sigma_z, mu_z+sigma_z)

lowerbound_z = mu_z-sigma_z;
%upperbound_z = mu_z+sigma_z;
upperbound_z = maximum_z;


minimum1_z = min(z(:,2));
maximum1_z = max(z(:,2));
size_BER64QAM = length(z(:,2));
pd1_z = fitdist(z(:,2),'Normal')
mu1_z = mean(z(:,2));
sigma1_z = std(z(:,2));
v1_z = var(z(:,2));

t1_z = truncate(pd1_z, mu1_z-sigma1_z, mu1_z+sigma1_z)

lowerbound1_z = mu1_z-sigma1_z;
%upperbound1_z = mu1_z+sigma1_z;
upperbound1_z = maximum1_z

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Apply Data Rate and Coded BER Threshold value/ truncated value for QPSK
%Finally we plot SNR vs DR plot
%we first truncate DR data, than BER data, so file size will be large if we
%do it inversely

%index = x<lowerbound | x>upperbound;

index_z = z>lowerbound_z & z<upperbound_z
z1 = z(index_z(:,1),:)
size1_z1 = length(z1);
minimum_z1 = min(z1);
maximum_z1 = max(z1);

%index1 = x1<lowerbound1 | x1>upperbound1; 
index1_z1 = z1>lowerbound1_z & z1<upperbound1_z
z2 = z1(index1_z1(:,2),:);
size2_z2 = length(z2);
minimum_z2 = min(z2);
maximum_z2 = max(z2);


z2 = sortrows(z2,1)

percentage_of_data_coverage_64QAM = (size2_z2/size_SNR64QAM)*100 

%%%%%%%%%%%%%%%% plot the graphs %%%%%%%%%%%%%%%%%%%

RGB = [255 153 153; 204 204 255];

pointsize = 5;
%scatter(x, y, pointsize, RGB, 'filled');

grid on;
scatter(x2(:,1), x2(:,2), 'g', 'filled');
hold on
scatter(y2(:,1), y2(:,2), 'r', 'filled');
hold on
scatter(z2(:,1), z2(:,2), 'b', 'filled');

legend ('QPSK', '16QAM', '64QAM');
xlabel('SNR'); ylabel ('Coded BER');
title('Scatter Plot of Link Adaptation [mu-sigma, mu+sigma]');

A = [size2_x2  size2_y2  size2_z2];
B = [size_SNRQPSK  size_SNR16QAM  size_SNR64QAM];


overall_classification_accuracy = (sum(A)/sum(B))*100

