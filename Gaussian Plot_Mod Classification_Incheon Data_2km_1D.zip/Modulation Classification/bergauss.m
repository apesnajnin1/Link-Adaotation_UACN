clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%p= Coded BER data, mu= Mean, sigma = Standard Deviation%%%%%%%%%
%% Input whole dataset

BER0 = load('BPSKBER_1km');
BER0 = cell2mat(struct2cell(BER0));
minimum0 = min(BER0);
maximum0 = max(BER0);
size_BPSK = length(BER0);
pd0 = fitdist(BER0,'Normal')
mu0 = mean(BER0);
sigma0 = std(BER0);
v0 = var(BER0);

t0 = truncate(pd0, mu0-0.5*sigma0, mu0+0.5*sigma0)

lowerbound0 = mu0-0.5*sigma0;
upperbound0 = mu0+0.5*sigma0;
index0 = BER0<lowerbound0 | BER0>upperbound0; 
BER0(index0)=[];
size0 = length(BER0)

percentage0 = (size0/size_BPSK)*100



BER = load('QPSKBER_1km');
BER = cell2mat(struct2cell(BER));
minimum = min(BER);
maximum = max(BER);
size_QPSK = length(BER);
pd = fitdist(BER,'Normal')
mu = mean(BER);
sigma = std(BER);
v = var(BER);

t = truncate(pd, mu-0.5*sigma, mu+0.5*sigma)

lowerbound = mu-0.5*sigma;
upperbound = mu+0.5*sigma;
index = BER<lowerbound | BER>upperbound; 
BER(index)=[];
size = length(BER)

percentage = (size/size_QPSK)*100


BER1 = load('x16QAMBER_1km');
BER1 = cell2mat(struct2cell(BER1));
minimum1 = min(BER1);
maximum1 = max(BER1);
size_16QAM = length(BER1);
pd1 = fitdist(BER1,'Normal')
mu1 = mean(BER1);
sigma1 = std(BER1);
v1 = var(BER1);


t1 = truncate(pd1, mu1-0.5*sigma1, mu1+0.5*sigma1)

lowerbound1 = mu1-0.5*sigma1;
upperbound1 = mu1+0.5*sigma1;
index1 = BER1<lowerbound1 | BER1>upperbound1; 
BER1(index1)=[];
size1 = length(BER1)

percentage1 = (size1/size_16QAM)*100


BER2 = load('x64QAMBER_1km');
BER2 = cell2mat(struct2cell(BER2));
minimum2 = min(BER2);
maximum2 = max(BER2);
size_64QAM = length(BER2);
pd2 = fitdist(BER2,'Normal')
mu2 = mean(BER2);
sigma2 = std(BER2);
v2 = var(BER2);

t2 = truncate(pd2, mu2-0.5*sigma2, mu2+0.5*sigma2)

lowerbound2 = mu2-0.5*sigma2;
upperbound2 = mu2+0.5*sigma2;
index2 = BER2<lowerbound2 | BER2>upperbound2; 
BER2(index2)=[];
size2 = length(BER2)

percentage2 = (size2/size_64QAM)*100

x = 0:0.01:0.52;



grid on


plot(x,pdf(pd0,x), 'Color', 'c')
hold on 
plot(x,pdf(pd,x), 'Color', 'g')
hold on
plot(x,pdf(pd1,x), 'Color', 'r')
hold on
plot(x,pdf(pd2,x), 'Color', 'b')

legend('BPSK Coded BER','QPSK Coded BER','16QAM Coded BER','64QAM Coded BER')
xlabel('Coded BER')
ylabel('Normal Distribution')
title('Normal Distribution Curve of BPSK, QPSK, 16QAM and 64QAM Coded BER [Coded Linear], Taean Data (1 km)');
hold off
%hold on

figure;
plot(x,pdf(t0,x), 'Color', 'c')
hold on
plot(x,pdf(t,x), 'Color', 'g')
hold on
plot(x,pdf(t1,x), 'Color', 'r')
hold on
plot(x,pdf(t2,x), 'Color', 'b')

legend('Truncated BPSK Coded BER','Truncated QPSK Coded BER','Truncated 16QAM Coded BER', 'Truncated 64QAM Coded BER')
xlabel('Coded BER')
ylabel('Normal Distribution')
title('Normal Distribution Curve of BPSK, QPSK, 16QAM and 64QAM Coded BER [Linear], Taean Data (1 km)');
hold off
