clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% rms_delayspread = RMS data, mu= Mean, sigma = Standard Deviation%%%%%%%%%

%rms0=load('RMSBPSK_1km');
%rms0= cell2mat(struct2cell(rms0));
%minimum0 = min(rms0);
%maximum0 = max(rms0);
%size_BPSK = length(rms0);


%lowerbound0 = minimum0;
%upperbound0 = 0.405;

%index0 = rms0<lowerbound0 | rms0>upperbound0; 
%rms0(index0)=[];
%size0 = length(rms0);

%data_percentage0 = (size0/size_BPSK)*100;

rms=load('RMSQPSK_15dB');
rms= cell2mat(struct2cell(rms));
minimum = min(rms);
maximum = max(rms);
size_QPSK = length(rms);


lowerbound = minimum;
upperbound = 7.5;

index = rms<lowerbound | rms>upperbound; 
rms(index)=[];
size = length(rms);

data_percentage = (size/size_QPSK)*100;

rms1=load('RMS16QAM_15dB');
rms1= cell2mat(struct2cell(rms1));
minimum1 = min(rms1);
maximum1 = max(rms1);
size_16QAM = length(rms1);


lowerbound1 = minimum1;
upperbound1 = 7.5;

index1 = rms1<lowerbound1 | rms1>upperbound1; 
rms1(index1)=[];
size1 = length(rms1);

data_percentage1 = (size1/size_16QAM)*100;

rms2=load('RMS64QAM_15dB');
rms2= cell2mat(struct2cell(rms2));
minimum2 = min(rms2);
maximum2 = max(rms2);
size_64QAM = length(rms2);


lowerbound2 = 7.5;
upperbound2 = maximum2;

index2 = rms2<lowerbound2 | rms2>upperbound2; 
rms2(index2)=[];
size2 = length(rms2);

data_percentage2 = (size2/size_64QAM)*100;

%A = [size0     size       size1        size2];
%B = [size_BPSK size_QPSK  size_16QAM   size_64QAM];

A = [size       size1        size2];
B = [size_QPSK  size_16QAM   size_64QAM];


classification_accuracy = (sum(A)/sum(B))*100