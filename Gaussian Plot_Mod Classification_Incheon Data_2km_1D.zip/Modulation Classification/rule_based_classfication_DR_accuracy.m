clear all;
clc;

%DR0 = load('BPSKDR_1km');
%DR0 = cell2mat(struct2cell(DR0));
%minimum0 = min(DR0);
%maximum0 = max(DR0);
%size_BPSK = length(DR0);

%lowerbound0 = minimum0;
%upperbound0 = 389;
%index0 = DR0<lowerbound0 | DR0>upperbound0; 
%DR0(index0)=[];
%size0 = length(DR0)

%data_percentage0 = (size0/size_BPSK)*100

DR = load('QPSKDR_1km');
DR = cell2mat(struct2cell(DR));
minimum = min(DR);
maximum = max(DR);
size_QPSK = length(DR);

lowerbound = 389;
upperbound = 807;
index = DR<lowerbound | DR>upperbound; 
DR(index)=[];
size = length(DR)

data_percentage = (size/size_QPSK)*100

DR1 = load('x16QAMDR_1km');
DR1 = cell2mat(struct2cell(DR1));
minimum1 = min(DR1);
maximum1 = max(DR1);
size_16QAM = length(DR1);

%lowerbound1 = 847.318;
%upperbound1 = 1612;
lowerbound1 = 807;
upperbound1 = 1678;
index1 = DR1<lowerbound1 | DR1>upperbound1; 
DR1(index1)=[];
size1 = length(DR1)

data_percentage1 = (size1/size_16QAM)*100

DR2 = load('x64QAMDR_1km');
DR2 = cell2mat(struct2cell(DR2));
minimum2 = min(DR2);
maximum2 = max(DR2);
size_64QAM = length(DR2);

lowerbound2 = 1678;
upperbound2 = maximum2;

%lowerbound2 = 1260.6;
%upperbound2 = maximum2;
index2 = DR2<lowerbound2 | DR2>upperbound2; 
DR2(index2)=[];
size2 = length(DR2)

data_percentage2 = (size2/size_64QAM)*100 

A = [size0      size      size1     size2];
B = [size_BPSK size_QPSK size_16QAM size_64QAM];


classification_accuracy = (sum(A)/sum(B))*100