clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% rms_delayspread = RMS data, mu= Mean, sigma = Standard Deviation%%%%%%%%%

%rms0=load('RMSBPSK_1km');
%rms0= cell2mat(struct2cell(rms0));
%minimum0 = min(rms0);
%maximum0 = max(rms0);
%size_BPSK = length(rms0);
%pd0 = fitdist(rms0,'Normal')
%mu0 = mean(pd0);
%sigma0 = std(pd0);
%v0 = var(pd0);


%t0 = truncate(pd0,mu0-0.5*sigma0,mu0+0.5*sigma0)
%t0 = truncate(pd0,mu0-sigma0,mu0+sigma0)

%lowerbound0 = mu0-sigma0;
%upperbound0 = mu0+sigma0;

%index0 = rms0<lowerbound0 | rms0>upperbound0; 
%rms0(index0)=[];
%size0 = length(rms0);

%percentage0 = (size0/size_BPSK)*100;


rms=load('RMSQPSK_15dB');
rms= cell2mat(struct2cell(rms));
minimum = min(rms);
maximum = max(rms);
size_QPSK = length(rms);
pd = fitdist(rms,'Normal')
mu = mean(pd);
sigma = std(pd);
v = var(pd);


%t = truncate(pd,mu-0.5*sigma,mu+0.5*sigma)
%t = truncate(pd,mu-sigma,mu+sigma)
t = truncate(pd,minimum,7.35)

lowerbound = mu-sigma;
upperbound = mu+sigma;

index = rms<lowerbound | rms>upperbound; 
rms(index)=[];
size = length(rms);

percentage = (size/size_QPSK)*100;

rms1=load('RMS16QAM_15dB');
rms1= cell2mat(struct2cell(rms1));
minimum1 = min(rms1);
maximum1 = max(rms1);
size_16QAM = length(rms1);
pd1 = fitdist(rms1,'Normal')
mu1 = mean(pd1);
sigma1 = std(pd1);
v1 = var(pd1);

%t1 = truncate(pd1,mu1-0.5*sigma1,mu1+0.5*sigma1)
%t1 = truncate(pd1,mu1-sigma1,mu1+sigma1)
t1 = truncate(pd1,minimum1,7.35)

lowerbound1 = mu1-sigma1;
upperbound1 = mu1+sigma1;

index1 = rms1<lowerbound1 | rms1>upperbound1; 
rms1(index1)=[];
size1 = length(rms1)

percentage1 = (size1/size_16QAM)*100

rms2=load('RMS64QAM_15dB');
rms2= cell2mat(struct2cell(rms2));
minimum2 = min(rms2);
maximum2 = max(rms2);
size_64QAM = length(rms2);
pd2 = fitdist(rms2,'Normal')
mu2 = mean(pd2);
sigma2 = std(pd2);
v2 = var(pd2);

%t2 = truncate(pd2,mu2-0.5*sigma2,mu2+0.5*sigma2)
%t2 = truncate(pd2,mu2-sigma2,mu2+sigma2)
t2 = truncate(pd2,7.35,maximum2)

lowerbound2 = mu2-sigma2;
upperbound2 = mu2+sigma2;

index2 = rms2<lowerbound2 | rms2>upperbound2; 
rms2(index2)=[];
size2 = length(rms2)

percentage2 = (size2/size_64QAM)*100


x = 0:0.1:18;

grid on;

%plot(x,pdf(pd0,x));
%hold on

plot(x,pdf(pd,x), 'Color', 'g')
hold on
plot(x,pdf(pd1,x), 'Color', 'r')
hold on
plot(x,pdf(pd2,x), 'Color', 'b')

%legend('BPSK RMS Delay Spread','QPSK RMS Delay Spread','16QAM RMS Delay Spread', '64QAM RMS Delay Spread')
legend('QPSK RMS Delay Spread','16QAM RMS Delay Spread', '64QAM RMS Delay Spread')
xlabel('RMS Delay Spread [Threshold: -15 dB]')
ylabel('Normal Distribution')
%title('Normal Distribution Curve of BPSK, QPSK, 16QAM and 64QAM RMS Delay Spread of Taean Data');
title('Normal Distribution Curve of QPSK, 16QAM and 64QAM RMS Delay Spread');
hold off

figure;
%plot(x,pdf(t0,x));
%hold on

plot(x,pdf(t,x), 'Color', 'g')
hold on
plot(x,pdf(t1,x), 'Color', 'r')
hold on
plot(x,pdf(t2,x), 'Color', 'b')

%legend('Truncated BPSK RMS Delay Spread','Truncated QPSK RMS Delay Spread','Truncated 16QAM RMS Delay Spread', 'Truncated 64QAM RMS Delay Spread')

legend('Truncated QPSK RMS','Truncated 16QAM RMS', 'Truncated 64QAM RMS')
xlabel('RMS Delay Spread [Threshold: -15 dB]')
ylabel('pdf of Gaussian Distribution')
%title('Normal Distribution Curve of QPSK, 16QAM and 64QAM RMS Delay Spread [mu-sigma, mu+sigma]');
hold off
