clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% rms_delayspread = RMS data, mu= Mean, sigma = Standard Deviation%%%%%%%%%

%rms0=load('RMSBPSK_1km');
%rms0= cell2mat(struct2cell(rms0));
%minimum0 = min(rms0);
%maximum0 = max(rms0);
%size_BPSK = length(rms0);
%pd0 = fitdist(rms0,'Normal')
%mu0 = mean(pd0);
%sigma0 = std(pd0);
%v0 = var(pd0);


%t0 = truncate(pd0,mu0-0.5*sigma0,mu0+0.5*sigma0)
%t0 = truncate(pd0,mu0-sigma0,mu0+sigma0)

%lowerbound0 = mu0-sigma0;
%upperbound0 = mu0+sigma0;

%index0 = rms0<lowerbound0 | rms0>upperbound0; 
%rms0(index0)=[];
%size0 = length(rms0);

%percentage0 = (size0/size_BPSK)*100;


med=load('MEDQPSK_15dB');
med= cell2mat(struct2cell(med));
minimum = min(med);
maximum = max(med);
size_QPSK = length(med);
pd = fitdist(med,'Normal')
mu = mean(pd);
sigma = std(pd);
v = var(pd);


t = truncate(pd,minimum,28.9)
%t = truncate(pd,mu-sigma,mu+sigma)

lowerbound = mu-sigma;
upperbound = mu+sigma;

index = med<lowerbound | med>upperbound; 
med(index)=[];
size = length(med);

percentage = (size/size_QPSK)*100;

med1=load('MED16QAM_15dB');
med1= cell2mat(struct2cell(med1));
minimum1 = min(med1);
maximum1 = max(med1);
size_16QAM = length(med1);
pd1 = fitdist(med1,'Normal')
mu1 = mean(pd1);
sigma1 = std(pd1);
v1 = var(pd1);

t1 = truncate(pd1,mu1-sigma1,28.9)
%t1 = truncate(pd1,mu1-sigma1,mu1+sigma1)

lowerbound1 = mu1-sigma1;
upperbound1 = mu1+sigma1;

index1 = med1<lowerbound1 | med1>upperbound1; 
med1(index1)=[];
size1 = length(med1)

percentage1 = (size1/size_16QAM)*100

med2=load('MED64QAM_15dB');
med2= cell2mat(struct2cell(med2));
minimum2 = min(med2);
maximum2 = max(med2);
size_64QAM = length(med2);
pd2 = fitdist(med2,'Normal')
mu2 = mean(pd2);
sigma2 = std(pd2);
v2 = var(pd2);

t2 = truncate(pd2,28.9,maximum2)
%t2 = truncate(pd2,mu2-sigma2,mu2+sigma2)

lowerbound2 = mu2-sigma2;
upperbound2 = mu2+sigma2;

index2 = med2<lowerbound2 | med2>upperbound2; 
med2(index2)=[];
size2 = length(med2)

percentage2 = (size2/size_64QAM)*100


x = 0:0.1:50;

grid on;

%plot(x,pdf(pd0,x));
%hold on

plot(x,pdf(pd,x));
hold on
plot(x,pdf(pd1,x));
hold on
plot(x,pdf(pd2,x));

%legend('BPSK MED','QPSK MED','16QAM MED', '64QAM MED')
legend('QPSK MED','16QAM MED', '64QAM MED')
xlabel('MED [Threshold: -15 dB]')
ylabel('Normal Distribution')
%title('Normal Distribution Curve of BPSK, QPSK, 16QAM and 64QAM MED of Taean Data');
title('Normal Distribution Curve of QPSK, 16QAM and 64QAM MED');
hold off

figure;
%plot(x,pdf(t0,x));
%hold on

plot(x,pdf(t,x), 'Color', 'g');
hold on
plot(x,pdf(t1,x), 'Color', 'r');
hold on
plot(x,pdf(t2,x), 'Color', 'b');

%legend('Truncated BPSK MED','Truncated QPSK MED','Truncated 16QAM MED', 'Truncated 64QAM MED')

legend('Truncated QPSK MED','Truncated 16QAM MED', 'Truncated 64QAM MED')
xlabel('MED [Threshold: -15 dB]')
ylabel('Normal Distribution')
%title('Normal Distribution Curve of QPSK, 16QAM and 64QAM MED [mu-sigma, mu+sigma]');
hold off
