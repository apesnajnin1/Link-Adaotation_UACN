%Accuracy of code rate classification

clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% Coherence BW = Coherence Bandwidth data, mu= Mean, sigma = Standard Deviation %%%%%%%%%

CB=load('CBQPSK_15dB_corr5');
CB= cell2mat(struct2cell(CB));
minimum = min(CB);
maximum = max(CB);
size_QPSK = length(CB);


lowerbound = 30;
upperbound = maximum;

index = CB<lowerbound | CB>upperbound; 
CB(index)=[];
size = length(CB);

data_percentage = (size/size_QPSK)*100;

CB1=load('CB16QAM_15dB_corr5');
CB1= cell2mat(struct2cell(CB1));
minimum1 = min(CB1);
maximum1 = max(CB1);
size_16QAM = length(CB1);


lowerbound1 = 30;
upperbound1 = maximum1;

index1 = CB1<lowerbound1 | CB1>upperbound1; 
CB1(index1)=[];
size1 = length(CB1);

data_percentage1 = (size1/size_16QAM)*100;

CB2=load('CB64QAM_15dB_corr5');
CB2= cell2mat(struct2cell(CB2));
minimum2 = min(CB2);
maximum2 = max(CB2);
size_64QAM = length(CB2);


lowerbound2 = minimum2;
upperbound2 = 30;

index2 = CB2<lowerbound2 | CB2>upperbound2; 
CB2(index2)=[];
size2 = length(CB2);

data_percentage2 = (size2/size_64QAM)*100;


A = [size               size1             size2];
B = [size_QPSK          size_16QAM        size_64QAM];


classification_accuracy = (sum(A)/sum(B))*100