clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% snr_delayspread = SNR data, mu= Mean, sigma = Standard Deviation %%%%%%%%%

%rms0=load('RMSBPSK_1km');
%rms0= cell2mat(struct2cell(rms0));
%minimum0 = min(rms0);
%maximum0 = max(rms0);
%size_BPSK = length(rms0);


%lowerbound0 = minimum0;
%upperbound0 = 0.405;

%index0 = rms0<lowerbound0 | rms0>upperbound0; 
%rms0(index0)=[];
%size0 = length(rms0);

%data_percentage0 = (size0/size_BPSK)*100;

snr=load('QPSKSNR');
snr= cell2mat(struct2cell(snr));
minimum = min(snr);
maximum = max(snr);
size_QPSK = length(snr);


lowerbound = 7.6;
upperbound = maximum;

index = snr<lowerbound | snr>upperbound; 
snr(index)=[];
size = length(snr);

data_percentage = (size/size_QPSK)*100;

snr1=load('x16QAMSNR');
snr1= cell2mat(struct2cell(snr1));
minimum1 = min(snr1);
maximum1 = max(snr1);
size_16QAM = length(snr1);


lowerbound1 = 5.7;
upperbound1 = 7.6;

index1 = snr1<lowerbound1 | snr1>upperbound1; 
snr1(index1)=[];
size1 = length(snr1);

data_percentage1 = (size1/size_16QAM)*100;

snr2=load('x64QAMSNR');
snr2= cell2mat(struct2cell(snr2));
minimum2 = min(snr2);
maximum2 = max(snr2);
size_64QAM = length(snr2);


lowerbound2 = minimum2;
upperbound2 = 5.7;

index2 = snr2<lowerbound2 | snr2>upperbound2; 
snr2(index2)=[];
size2 = length(snr2);

data_percentage2 = (size2/size_64QAM)*100;

%A = [size0     size       size1        size2];
%B = [size_BPSK size_QPSK  size_16QAM   size_64QAM];

A = [size       size1        size2];
B = [size_QPSK  size_16QAM   size_64QAM];


classification_accuracy = (sum(A)/sum(B))*100