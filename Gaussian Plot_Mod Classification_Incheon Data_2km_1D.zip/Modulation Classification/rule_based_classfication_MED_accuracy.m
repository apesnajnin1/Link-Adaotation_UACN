clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% MED = Mean Estimated Delay data, mu= Mean, sigma = Standard Deviation %%%%%%%%%

med=load('MEDQPSK_15dB');
med= cell2mat(struct2cell(med));
minimum = min(med);
maximum = max(med);
size_QPSK = length(med);


lowerbound = minimum;
upperbound = 28.9;

index = med<lowerbound | med>upperbound; 
med(index)=[];
size = length(med);

data_percentage = (size/size_QPSK)*100;

med1=load('MED16QAM_15dB');
med1= cell2mat(struct2cell(med1));
minimum1 = min(med1);
maximum1 = max(med1);
size_16QAM = length(med1);

lowerbound1 = minimum1;
upperbound1 = 28.9;

index1 = med1<lowerbound1 | med1>upperbound1; 
med1(index1)=[];
size1 = length(med1);

data_percentage1 = (size1/size_16QAM)*100;

med2=load('MED64QAM_15dB');
med2= cell2mat(struct2cell(med2));
minimum2 = min(med2);
maximum2 = max(med2);
size_64QAM = length(med2);

lowerbound2 = 28.9;
upperbound2 = maximum2;

index2 = med2<lowerbound2 | med2>upperbound2; 
med2(index2)=[];
size2 = length(med2);

data_percentage2 = (size2/size_64QAM)*100;

A = [size                size1                 size2];
B = [size_QPSK           size_16QAM            size_64QAM];


classification_accuracy = (sum(A)/sum(B))*100