clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%p= Data Rate, mu= Mean, sigma = Standard Deviation%%%%%%%%%
%% input whole Dataset

%DR0 = load('BPSKDR_1km');
%DR0 = cell2mat(struct2cell(DR0));
%minimum0 = min(DR0);
%maximum0 = max(DR0);
%size_BPSK = length(DR0);
%pd0 = fitdist(DR0,'Normal')
%mu0 = mean(DR0);
%sigma0 = std(DR0);
%v0 = var(DR0);

%t0 = truncate(pd0, mu0-0.5*sigma0, mu0+0.5*sigma0)

%lowerbound0 = mu0-0.5*sigma0;
%upperbound0 = mu0+0.5*sigma0;
%index0 = DR0<lowerbound0 | DR0>upperbound0; 
%DR0(index0)=[];
%size0 = length(DR0)

%percentage0 = (size0/size_BPSK)*100


DR = load('QPSKDR');
DR = cell2mat(struct2cell(DR));
minimum = min(DR);
maximum = max(DR);
size_QPSK = length(DR);
pd = fitdist(DR,'Normal')
mu = mean(DR);
sigma = std(DR);
v = var(DR);

%t = truncate(pd, mu-sigma, mu+sigma)
t = truncate(pd, minimum, mu+sigma)
%lowerbound = mu-0.5*sigma;
lowerbound = minimum;
upperbound = mu+sigma;
index = DR<lowerbound | DR>upperbound; 
DR(index)=[];
size = length(DR)

percentage = (size/size_QPSK)*100


DR1 = load('x16QAMDR');
DR1 = cell2mat(struct2cell(DR1));
minimum1 = min(DR1);
maximum1 = max(DR1);
size_16QAM = length(DR1);
pd1 = fitdist(DR1,'Normal')
mu1 = mean(DR1);
sigma1 = std(DR1);
v1 = var(DR1);

%t1 = truncate(pd1, mu1-sigma1, mu1+sigma1)
t1 = truncate(pd1, 980, mu1+sigma1)

%lowerbound1 = mu1-0.5*sigma1;
%upperbound1 = mu1+0.5*sigma1;

lowerbound1 = 980;
upperbound1 = 1964;
index1 = DR1<lowerbound1 | DR1>upperbound1; 
DR1(index1)=[];
size1 = length(DR1)

percentage1 = (size1/size_16QAM)*100


DR2 = load('x64QAMDR');
DR2 = cell2mat(struct2cell(DR2));
minimum2 = min(DR2);
maximum2 = max(DR2);
size_64QAM = length(DR2);
pd2 = fitdist(DR2,'Normal')
mu2 = mean(DR2);
sigma2 = std(DR2);
v2 = var(DR2);

%t2 = truncate(pd2, mu2-sigma2, mu2+sigma2)
t2 = truncate(pd2, 1964, maximum2)

lowerbound2 = mu2-sigma2;
%upperbound2 = mu2+0.5*sigma2;
upperbound2 = maximum2;
index2 = DR2<lowerbound2 | DR2>upperbound2; 
DR2(index2)=[];
size2 = length(DR2)

percentage2 = (size2/size_64QAM)*100

x = 9:1:8000;

grid on

%figure;
%plot(x,pdf(pd0,x))
%hold on
plot(x,pdf(pd,x))
hold on
plot(x,pdf(pd1,x))
hold on
plot(x,pdf(pd2,x))
legend('QPSK','16QAM', '64QAM')
xlabel('Data Rate [bps]')
ylabel('Normal Distribution')
title('Normal Distribution Curve of QPSK, 16QAM and 64QAM Data Rate');
hold off

figure;
%plot(x,pdf(t0,x))
%hold on
plot(x,pdf(t,x), 'Color', 'g')
hold on
plot(x,pdf(t1,x), 'Color', 'r')
hold on
plot(x,pdf(t2,x), 'Color', 'b')
legend('Truncated QPSK Data Rate','Truncated 16QAM Data Rate', 'Truncated 64QAM Data Rate')
xlabel('Data Rate [bps]')
ylabel('pdf of Gaussian Distribution')
%title('Normal Distribution Curve of QPSK, 16QAM and 64QAM Data Rate for [mu-sigma, mu+sigma]');
hold off






