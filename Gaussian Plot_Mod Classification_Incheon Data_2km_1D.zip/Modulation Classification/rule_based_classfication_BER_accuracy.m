clear all;
clc;

BER0 = load('BPSKBER_1km');
BER0 = cell2mat(struct2cell(BER0));
minimum0 = min(BER0);
maximum0 = max(BER0);
size_BPSK = length(BER0);

lowerbound0 = minimum0;
upperbound0 = 0.03;
index0 = BER0<lowerbound0 | BER0>upperbound0; 
BER0(index0)=[];
size0 = length(BER0)

data_percentage0 = (size0/size_BPSK)*100

BER = load('QPSKBER_1km');
BER = cell2mat(struct2cell(BER));
minimum = min(BER);
maximum = max(BER);
size_QPSK = length(BER);

lowerbound = 0.03;
upperbound = 0.08;
index = BER<lowerbound | BER>upperbound; 
BER(index)=[];
size = length(BER)

data_percentage = (size/size_QPSK)*100

BER1 = load('x16QAMBER_1km');
BER1 = cell2mat(struct2cell(BER1));
minimum1 = min(BER1);
maximum1 = max(BER1);
size_16QAM = length(BER1);

lowerbound1 = 0.08;
upperbound1 = 0.13;
index1 = BER1<lowerbound1 | BER1>upperbound1; 
BER1(index1)=[];
size1 = length(BER1)

data_percentage1 = (size1/size_16QAM)*100

BER2 = load('x64QAMBER_1km');
BER2 = cell2mat(struct2cell(BER2));
minimum2 = min(BER2);
maximum2 = max(BER2);
size_64QAM = length(BER2);

lowerbound2 = 0.13;
upperbound2 = maximum2;
index2 = BER2<lowerbound2 | BER2>upperbound2; 
BER2(index2)=[];
size2 = length(BER2)

data_percentage2 = (size2/size_64QAM)*100 

A = [size0     size      size1      size2];
B = [size_BPSK size_QPSK size_16QAM size_64QAM];


classification_accuracy = (sum(A)/sum(B))*100