clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%p= SNR data, mu= Mean, sigma = Standard Deviation%%%%%%%%%
%% Input whole dataset

% Incheon Data: QPSKSNR, Taean Data: QPSKSNR_1km

BER0 = load('BPSKSNR');
BER0 = cell2mat(struct2cell(BER0));
minimum0 = min(BER0);
maximum0 = max(BER0);
size_BPSK = length(BER0);
pd0 = fitdist(BER0,'Normal')
mu0 = mean(BER0);
sigma0 = std(BER0);
v0 = var(BER0);

t0 = truncate(pd0, mu0-0.5*sigma0, mu0+0.5*sigma0)

lowerbound0 = mu0-0.5*sigma0;
upperbound0 = mu0+0.5*sigma0;
index0 = BER0<lowerbound0 | BER0>upperbound0; 
BER0(index0)=[];
size0 = length(BER0)

percentage0 = (size0/size_BPSK)*100



SNR = load('QPSKSNR');
SNR = cell2mat(struct2cell(SNR));
minimum = min(SNR);
maximum = max(SNR);
size_QPSK = length(SNR);
pd = fitdist(SNR,'Normal')
mu = mean(SNR);
sigma = std(SNR);
v = var(SNR);

%t = truncate(pd, mu-sigma, mu+sigma)
t = truncate(pd, mu-0.5*sigma, mu+0.5*sigma)

lowerbound = mu-0.5*sigma;
upperbound = mu+0.5*sigma;
index = SNR<lowerbound | SNR>upperbound; 
SNR(index)=[];
size = length(SNR)

percentage = (size/size_QPSK)*100


SNR1 = load('x16QAMSNR');
SNR1 = cell2mat(struct2cell(SNR1));
minimum1 = min(SNR1);
maximum1 = max(SNR1);
size_16QAM = length(SNR1);
pd1 = fitdist(SNR1,'Normal')
mu1 = mean(SNR1);
sigma1 = std(SNR1);
v1 = var(SNR1);


t1 = truncate(pd1, mu1-0.5*sigma1, mu1+0.5*sigma1)

lowerbound1 = mu1-0.5*sigma1;
upperbound1 = mu1+0.5*sigma1;
index1 = SNR1<lowerbound1 | SNR1>upperbound1; 
SNR1(index1)=[];
size1 = length(SNR1)

percentage1 = (size1/size_16QAM)*100


SNR2 = load('x64QAMSNR');
SNR2 = cell2mat(struct2cell(SNR2));
minimum2 = min(SNR2);
maximum2 = max(SNR2);
size_64QAM = length(SNR2);
pd2 = fitdist(SNR2,'Normal')
mu2 = mean(SNR2);
sigma2 = std(SNR2);
v2 = var(SNR2);

%t2 = truncate(pd2, mu2-sigma2, mu2+sigma2)
t2 = truncate(pd2, mu2-0.5*sigma2, mu2+0.5*sigma2)

lowerbound2 = mu2-0.5*sigma2;
upperbound2 = mu2+0.5*sigma2;
index2 = SNR2<lowerbound2 | SNR2>upperbound2; 
SNR2(index2)=[];
size2 = length(SNR2)

percentage2 = (size2/size_64QAM)*100

x = 0:0.1:25;



grid on


plot(x,pdf(pd0,x), 'Color', 'c')
hold on 
plot(x,pdf(pd,x), 'Color', 'g')
hold on
plot(x,pdf(pd1,x), 'Color', 'r')
hold on
plot(x,pdf(pd2,x), 'Color', 'b')

legend('BPSK SNR', 'QPSK SNR', '16QAM SNR', '64QAM SNR')

xlabel('SNR')
ylabel('pdf of Gaussian Distribution')
title('pdf of Gaussian Distribution Curve of BPSK, QPSK, 16QAM and 64QAM SNR');
%title('Normal Distribution Curve of QPSK, 16QAM and 64QAM SNR');
hold off
%hold on

figure;
plot(x,pdf(t0,x), 'Color', 'c')
hold on
plot(x,pdf(t,x), 'Color', 'g')
hold on
plot(x,pdf(t1,x), 'Color', 'r')
hold on
plot(x,pdf(t2,x), 'Color', 'b')

legend('Truncated BPSK SNR', 'Truncated QPSK SNR', 'Truncated 16QAM SNR', 'Truncated 64QAM SNR')

xlabel('SNR')
ylabel('pdf of Gaussian Distribution')
title('pdf of Gaussian Distribution Curve of BPSK, QPSK, 16QAM and 64QAM SNR [-0.5sigma, 0.5sigma]');
hold off
