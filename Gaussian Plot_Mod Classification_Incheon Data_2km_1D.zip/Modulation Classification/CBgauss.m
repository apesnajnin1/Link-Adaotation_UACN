clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% CB = RMS data, mu= Mean, sigma = Standard Deviation%%%%%%%%%

%rms0=load('RMSBPSK_1km');
%rms0= cell2mat(struct2cell(rms0));
%minimum0 = min(rms0);
%maximum0 = max(rms0);
%size_BPSK = length(rms0);
%pd0 = fitdist(rms0,'Normal')
%mu0 = mean(pd0);
%sigma0 = std(pd0);
%v0 = var(pd0);


%t0 = truncate(pd0,mu0-0.5*sigma0,mu0+0.5*sigma0)
%t0 = truncate(pd0,mu0-sigma0,mu0+sigma0)

%lowerbound0 = mu0-sigma0;
%upperbound0 = mu0+sigma0;

%index0 = rms0<lowerbound0 | rms0>upperbound0; 
%rms0(index0)=[];
%size0 = length(rms0);

%percentage0 = (size0/size_BPSK)*100;


CB=load('CBQPSK_15dB_corr5');
CB= cell2mat(struct2cell(CB));
minimum = min(CB);
maximum = max(CB);
size_QPSK = length(CB);
pd = fitdist(CB,'Normal')
mu = mean(pd);
sigma = std(pd);
v = var(pd);


%t = truncate(pd,mu-0.5*sigma,mu+0.5*sigma)
%t = truncate(pd,mu-sigma,mu+sigma)
t = truncate(pd,100,maximum)

lowerbound = mu-sigma;
upperbound = mu+sigma;

index = CB<lowerbound | CB>upperbound; 
CB(index)=[];
size = length(CB);

percentage = (size/size_QPSK)*100;

CB1=load('CB16QAM_15dB_corr5');
CB1= cell2mat(struct2cell(CB1));
minimum1 = min(CB1);
maximum1 = max(CB1);
size_16QAM = length(CB1);
pd1 = fitdist(CB1,'Normal')
mu1 = mean(pd1);
sigma1 = std(pd1);
v1 = var(pd1);

%t1 = truncate(pd1,mu1-0.5*sigma1,mu1+0.5*sigma1)
%t1 = truncate(pd1,mu1-sigma1,mu1+sigma1)
t1 = truncate(pd1,100,maximum1)

lowerbound1 = mu1-sigma1;
upperbound1 = mu1+sigma1;

index1 = CB1<lowerbound1 | CB1>upperbound1; 
CB1(index1)=[];
size1 = length(CB1)

percentage1 = (size1/size_16QAM)*100

CB2=load('CB64QAM_15dB_corr5');
CB2= cell2mat(struct2cell(CB2));
minimum2 = min(CB2);
maximum2 = max(CB2);
size_64QAM = length(CB2);
pd2 = fitdist(CB2,'Normal')
mu2 = mean(pd2);
sigma2 = std(pd2);
v2 = var(pd2);

%t2 = truncate(pd2,mu2-0.5*sigma2,mu2+0.5*sigma2)
%t2 = truncate(pd2,mu2-sigma2,mu2+sigma2)
t2 = truncate(pd2,minimum2,100)

lowerbound2 = mu2-sigma2;
upperbound2 = mu2+sigma2;

index2 = CB2<lowerbound2 | CB2>upperbound2; 
CB2(index2)=[];
size2 = length(CB2)

percentage2 = (size2/size_64QAM)*100


x = 0:1:2500;
axis([0 2500 0 8*10^-3])
grid on;

%plot(x,pdf(pd0,x));
%hold on

plot(x,pdf(pd,x),'color', 'g');
hold on
plot(x,pdf(pd1,x), 'color', 'r');
hold on
plot(x,pdf(pd2,x), 'color', 'b');
axis([0 2500 0 8*10^-3])

%legend('BPSK RMS Delay Spread','QPSK RMS Delay Spread','16QAM RMS Delay Spread', '64QAM RMS Delay Spread')
legend('QPSK Coh BW','16QAM Coh BW', '64QAM Coh BW')
xlabel('Coherence BW [Threshold: -15 dB]')
ylabel('Normal Distribution')
%title('Normal Distribution Curve of BPSK, QPSK, 16QAM and 64QAM RMS Delay Spread of Taean Data');
title('Normal Distribution Curve of QPSK, 16QAM and 64QAM Coherence BW');
hold off

figure;
%plot(x,pdf(t0,x));
%hold on

plot(x,pdf(t,x),'color', 'g');
hold on
plot(x,pdf(t1,x), 'color', 'r');
hold on
plot(x,pdf(t2,x), 'color', 'b');
axis([0 2500 0 8*10^-3])

%legend('Truncated BPSK RMS Delay Spread','Truncated QPSK RMS Delay Spread','Truncated 16QAM RMS Delay Spread', 'Truncated 64QAM RMS Delay Spread')

%legend('Truncated QPSK Coherence BW','Truncated 16QAM Coherence BW', 'Truncated 64QAM Coherence BW')
xlabel('Coherence BW [Threshold: -15 dB]')
ylabel('pdf of Gausian Distribution')
%title('Normal Distribution Curve of QPSK, 16QAM and 64QAM Coherence BW [mu-sigma, mu+sigma]');
hold off
