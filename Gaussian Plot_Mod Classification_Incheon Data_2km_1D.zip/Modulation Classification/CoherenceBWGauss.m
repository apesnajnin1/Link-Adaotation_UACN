clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%Axis Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%p= Coherence Bandwidth data, mu= Mean, sigma = Standard Deviation%%%%%%%%%
%% Input whole dataset

%BER0 = load('BPSKSNR');
%BER0 = cell2mat(struct2cell(BER0));
%minimum0 = min(BER0);
%maximum0 = max(BER0);
%size_BPSK = length(BER0);
%pd0 = fitdist(BER0,'Normal')
%mu0 = mean(BER0);
%sigma0 = std(BER0);
%v0 = var(BER0);

%t0 = truncate(pd0, mu0-0.5*sigma0, mu0+0.5*sigma0)

%lowerbound0 = mu0-0.5*sigma0;
%upperbound0 = mu0+0.5*sigma0;
%index0 = BER0<lowerbound0 | BER0>upperbound0; 
%BER0(index0)=[];
%size0 = length(BER0)

%percentage0 = (size0/size_BPSK)*100



CohBW = load('QPSKCohBW');
CohBW = cell2mat(struct2cell(CohBW));
minimum = min(CohBW);
maximum = max(CohBW);
size_QPSK = length(CohBW);
pd = fitdist(CohBW,'Normal')
mu = mean(CohBW);
sigma = std(CohBW);
v = var(CohBW);

%t = truncate(pd, mu-0.5*sigma, mu+0.5*sigma)

%lowerbound = mu-0.5*sigma;
%upperbound = mu+0.5*sigma;

%t = truncate(pd, mu-sigma, mu+sigma)
t = truncate(pd, 100, maximum)

lowerbound = mu-sigma;
upperbound = mu+sigma;

index = CohBW<lowerbound | CohBW>upperbound; 
CohBW(index)=[];
size = length(CohBW)

percentage = (size/size_QPSK)*100


CohBW1 = load('x16QAMCohBW');
CohBW1 = cell2mat(struct2cell(CohBW1));
minimum1 = min(CohBW1);
maximum1 = max(CohBW1);
size_16QAM = length(CohBW1);
pd1 = fitdist(CohBW1,'Normal')
mu1 = mean(CohBW1);
sigma1 = std(CohBW1);
v1 = var(CohBW1);


%t1 = truncate(pd1, mu1-sigma1, mu1+sigma1)
t1 = truncate(pd1, 100, maximum1)

lowerbound1 = mu1-sigma1;
upperbound1 = mu1+sigma1;
index1 = CohBW1<lowerbound1 | CohBW1>upperbound1; 
CohBW1(index1)=[];
size1 = length(CohBW1)

percentage1 = (size1/size_16QAM)*100


CohBW2 = load('x64QAMCohBW');
CohBW2 = cell2mat(struct2cell(CohBW2));
minimum2 = min(CohBW2);
maximum2 = max(CohBW2);
size_64QAM = length(CohBW2);
pd2 = fitdist(CohBW2,'Normal')
mu2 = mean(CohBW2);
sigma2 = std(CohBW2);
v2 = var(CohBW2);

%t2 = truncate(pd2, mu2-sigma2, mu2+sigma2)
t2 = truncate(pd2, minimum2, 100)

lowerbound2 = mu2-sigma2;
upperbound2 = mu2+sigma2;
index2 = CohBW2<lowerbound2 | CohBW2>upperbound2; 
CohBW2(index2)=[];
size2 = length(CohBW2)

percentage2 = (size2/size_64QAM)*100

x = 0:1:2100;



grid on


%plot(x,pdf(pd0,x), 'Color', 'c')
%hold on 
plot(x,pdf(pd,x), 'Color', 'g')
hold on
plot(x,pdf(pd1,x), 'Color', 'r')
hold on
plot(x,pdf(pd2,x), 'Color', 'b')

%legend('BPSK Coded BER','QPSK Coded BER','16QAM Coded BER','64QAM Coded BER')
legend('QPSK CohBW','16QAM CohBW','64QAM CohBW')
xlabel('Coherence Bandwidth')
ylabel('Normal Distribution')
%title('Normal Distribution Curve of BPSK, QPSK, 16QAM and 64QAM Coded BER [Coded Linear], Taean Data (1 km)');
title('Normal Distribution Curve of QPSK, 16QAM and 64QAM Coherence BW [- 10 dB, corr 5], Incheon Data');
hold off
%hold on

figure;
%plot(x,pdf(t0,x), 'Color', 'c')
%hold on
plot(x,pdf(t,x), 'Color', 'g')
hold on
plot(x,pdf(t1,x), 'Color', 'r')
hold on
plot(x,pdf(t2,x), 'Color', 'b')
axis ([0 2100 0 0.014])

%legend('Truncated BPSK Coded BER','Truncated QPSK Coded BER','Truncated 16QAM Coded BER', 'Truncated 64QAM Coded BER')
legend('Truncated QPSK Coherence BW','Truncated 16QAM Coherence BW', 'Truncated 64QAM Coherence BW')
xlabel('Coherence Bandwidth [ Threshold: -15 dB]')
ylabel('pdf of gaussian Distribution')
%title('Normal Distribution Curve of QPSK, 16QAM and 64QAM Coherence BW [-10 dB, corr 5], Incheon Data');
hold off
