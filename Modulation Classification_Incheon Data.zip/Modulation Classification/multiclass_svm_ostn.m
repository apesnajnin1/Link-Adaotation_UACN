%% Predict Test-Sample Labels of Training Data Using ECOC Models
%%
% Load OSTN data set.
clear;
clc;
tic;

load PCAdata04_SNR20
load Allmodulations
X = PCAdata04_SNR20; 
Y = categorical(Allmodulations);
classOrder = unique(Y);
rng(1); % For reproducibility


%%%%%%%%
% Train an ECOC model using SVM binary classifiers and specify a 30%
% holdout sample. It is good practice to define the class order. Specify to
% standardize the predictors using an SVM template.
%CV = cross validation

%t = templateSVM('Standardize',1); %svm
%t = templateSVM('Standardize',true,'KernelFunction','gaussian');
%t = templateKNN('Standardize',1); %knn
%
%t = templateNaiveBayes('DistributionNames','kernel');  %naive bayes
%t = templateTree('Surrogate','on','MaxNumSplits',2000,'MergeLeaves','on','MinLeafSize',20,'MinParentSize',20, 'NumVariablesToSample','all'); %tree
%t = templateDiscriminant('DiscrimType','pseudolinear'); % discriminant analysis/linear discriminant analysis (LDA)
%%%%%%%tree%%%%%%%%%

%CVMdl = fitcensemble(X,Y,'Holdout',0.30,'Method','AdaBoostM2','Learners',t);

%%%%%%%original code%%%%%%%%%%%%%%%%%%%%
t = templateKNN('Standardize',1); %knn
%t = templateTree('Surrogate','on','MaxNumSplits',2000,'MergeLeaves','on','MinLeafSize',20,'MinParentSize',20, 'NumVariablesToSample','all'); %tree
CVMdl = fitcecoc(X,Y,'Holdout',0.30,'Learners',t,'ClassNames',classOrder);
%CVMdl = fitcensemble(X,Y,'Holdout',0.30,'Method','AdaBoostM2','Learners',t);
CMdl = CVMdl.Trained{1};           % Extract trained, compact classifier
testInds = test(CVMdl.Partition);  % Extract the test indices 
XTest = X(testInds,:);
YTest = Y(testInds,:);

%%%%%%%%%end%%%%%%%%%%%%%%%%%%%


%%
% |CVMdl| is a |ClassificationPartitionedECOC| model. It contains the
% property |Trained|, which is a 1-by-1 cell array holding a
% |CompactClassificationECOC| model that the software trained using the
% training set.
%%
% Predict the test-sample labels.  Print a random subset of true
% and predicted labels.
%CMdl_ClassNames = getclassname(CMdl, X, Y)
%classOrder = getclassname(CMdl, X, Y)
%labels = predict(CMdl,XTest, 'ClassNames', classOrder);
labels = predict(CMdl,XTest);
plotconfusion(YTest,labels);

%idx = randsample(sum(testInds),30);
%table(YTest(idx),labels(idx),...
 %   'VariableNames',{'TrueLabels','PredictedLabels'})

Classification_Accuracy = sum((predict(CMdl,XTest) == YTest))/length(YTest)*100
toc