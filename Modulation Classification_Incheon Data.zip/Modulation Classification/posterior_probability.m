%% Estimate Posterior Probabilities Using ECOC Classifiers
%%
% Load Fisher's iris data set.  Train the classifier using the petal
% dimensions as predictors.

% Copyright 2015 The MathWorks, Inc.

load data
load modulations
X = data(:,2:3);
Y = modulations;
rng(1); % For reproducibility
%%
% Create an SVM template, and specify the Gaussian kernel.  It is
% good practice to standardize the predictors.
t = templateSVM('Standardize',1,'KernelFunction','gaussian');
%%
% |t| is an SVM template. Most of its properties are empty. When the
% software trains the ECOC classifier, it sets the applicable properties to
% their default values.
%%
% Train the ECOC classifier using the SVM template. Transform
% classification scores to class posterior probabilities (which are
% returned by |predict| or |resubPredict|) using the |'FitPosterior'|
% name-value pair argument.   Display diagnostic messages during the
% training using the |'Verbose'| name-value pair argument. It is good
% practice to specify the class order.
Mdl = fitcecoc(X,Y,'Learners',t,'FitPosterior',1,...
    'ClassNames',{'16-QAM','64-QAM','QPSK'},...
    'Verbose',2);
%%
% |Mdl| is a |ClassificationECOC| model.  The same SVM template applies to
% each binary learner, but you can adjust options for each binary learner by
% passing in a cell vector of templates.
%% 
% Predict the in-sample labels and class posterior probabilities.  Display
% diagnostic messages during the computation of labels and class posterior
% probabilities using the |'Verbose'| name-value pair argument.
[label,~,~,Posterior] = resubPredict(Mdl,'Verbose',1);
Mdl.BinaryLoss
%%
% The software assigns an observation to the class that yields the smallest
% average binary loss.  Since all binary learners are computing posterior
% probabilities, the binary loss function is |quadratic|.
%%
% Display a random set of results.
idx = randsample(size(X,1),10,1);
Mdl.ClassNames
table(Y(idx),label(idx),Posterior(idx,:),...
    'VariableNames',{'TrueLabel','PredLabel','Posterior'})
%%
% The columns of |Posterior| correspond to the class order of
% |Mdl.ClassNames|.
%%
% Define a grid of values in the observed predictor space. Predict the
% posterior probabilities for each instance in the grid.
xMax = max(X);
xMin = min(X);

x1Pts = linspace(xMin(1),xMax(1));
x2Pts = linspace(xMin(2),xMax(2));
[x1Grid,x2Grid] = meshgrid(x1Pts,x2Pts);

[~,~,~,PosteriorRegion] = predict(Mdl,[x1Grid(:),x2Grid(:)]);
%%
% For each coordinate on the grid, plot the maximum class posterior
% probability among all classes.
figure;
contourf(x1Grid,x2Grid,...
        reshape(max(PosteriorRegion,[],2),size(x1Grid,1),size(x1Grid,2)));
h = colorbar;
h.YLabel.String = 'Maximum posterior';
h.YLabel.FontSize = 15;
hold on
gh = gscatter(X(:,1),X(:,2),Y,'krk','*xd',8);
gh(2).LineWidth = 2;
gh(3).LineWidth = 2;

title 'OSTN Data Rate, SNR and Maximum Posterior';
xlabel 'SNR (dB)';
ylabel 'Data Rate (bps)';
axis tight
legend(gh,'Location','NorthWest')
hold off
